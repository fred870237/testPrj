﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NCalc;

namespace PrjNcalcExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            try
            {
                // formula 1
                Expression tempExpression = new Expression(this.txtFormula1.Text);
                tempExpression.Parameters["X"] = Convert.ToDouble(this.txtX.Text);
                tempExpression.Parameters["x"] = Convert.ToDouble(this.txtX.Text);

                tempExpression.Parameters["Y"] = Convert.ToDouble(this.txtY.Text);
                tempExpression.Parameters["y"] = Convert.ToDouble(this.txtY.Text);

                tempExpression.Parameters["Z"] = Convert.ToDouble(this.txtZ.Text);
                tempExpression.Parameters["z"] = Convert.ToDouble(this.txtZ.Text);

                double result = Convert.ToDouble(tempExpression.Evaluate());
                this.txtResult1.Text = result.ToString("F4");


                // formula 2
                tempExpression = new Expression(this.txtFormula2.Text);
                tempExpression.Parameters["X"] = Convert.ToDouble(this.txtX.Text);
                tempExpression.Parameters["x"] = Convert.ToDouble(this.txtX.Text);

                tempExpression.Parameters["Y"] = Convert.ToDouble(this.txtY.Text);
                tempExpression.Parameters["y"] = Convert.ToDouble(this.txtY.Text);

                tempExpression.Parameters["Z"] = Convert.ToDouble(this.txtZ.Text);
                tempExpression.Parameters["z"] = Convert.ToDouble(this.txtZ.Text);

                result = Convert.ToDouble(tempExpression.Evaluate());
                this.txtResult2.Text = result.ToString("F4");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());   
            }
        }
    }
}
