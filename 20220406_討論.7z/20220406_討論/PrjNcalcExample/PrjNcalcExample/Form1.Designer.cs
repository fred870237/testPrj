﻿
namespace PrjNcalcExample
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalc = new System.Windows.Forms.Button();
            this.lblX = new System.Windows.Forms.Label();
            this.lblY = new System.Windows.Forms.Label();
            this.lblZ = new System.Windows.Forms.Label();
            this.txtX = new System.Windows.Forms.TextBox();
            this.txtY = new System.Windows.Forms.TextBox();
            this.txtZ = new System.Windows.Forms.TextBox();
            this.txtFormula1 = new System.Windows.Forms.TextBox();
            this.lblFormula1 = new System.Windows.Forms.Label();
            this.lblFormula2 = new System.Windows.Forms.Label();
            this.txtFormula2 = new System.Windows.Forms.TextBox();
            this.txtResult1 = new System.Windows.Forms.TextBox();
            this.txtResult2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(349, 172);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(75, 50);
            this.btnCalc.TabIndex = 0;
            this.btnCalc.Text = "Calc";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // lblX
            // 
            this.lblX.AutoSize = true;
            this.lblX.Location = new System.Drawing.Point(90, 15);
            this.lblX.Name = "lblX";
            this.lblX.Size = new System.Drawing.Size(17, 20);
            this.lblX.TabIndex = 1;
            this.lblX.Text = "X";
            // 
            // lblY
            // 
            this.lblY.AutoSize = true;
            this.lblY.Location = new System.Drawing.Point(90, 47);
            this.lblY.Name = "lblY";
            this.lblY.Size = new System.Drawing.Size(18, 20);
            this.lblY.TabIndex = 2;
            this.lblY.Text = "Y";
            // 
            // lblZ
            // 
            this.lblZ.AutoSize = true;
            this.lblZ.Location = new System.Drawing.Point(90, 79);
            this.lblZ.Name = "lblZ";
            this.lblZ.Size = new System.Drawing.Size(16, 20);
            this.lblZ.TabIndex = 3;
            this.lblZ.Text = "Z";
            // 
            // txtX
            // 
            this.txtX.Location = new System.Drawing.Point(113, 12);
            this.txtX.Name = "txtX";
            this.txtX.Size = new System.Drawing.Size(100, 26);
            this.txtX.TabIndex = 4;
            this.txtX.Text = "5";
            // 
            // txtY
            // 
            this.txtY.Location = new System.Drawing.Point(113, 44);
            this.txtY.Name = "txtY";
            this.txtY.Size = new System.Drawing.Size(100, 26);
            this.txtY.TabIndex = 5;
            this.txtY.Text = "10";
            // 
            // txtZ
            // 
            this.txtZ.Location = new System.Drawing.Point(113, 76);
            this.txtZ.Name = "txtZ";
            this.txtZ.Size = new System.Drawing.Size(100, 26);
            this.txtZ.TabIndex = 6;
            this.txtZ.Text = "0.5";
            // 
            // txtFormula1
            // 
            this.txtFormula1.Location = new System.Drawing.Point(78, 108);
            this.txtFormula1.Name = "txtFormula1";
            this.txtFormula1.Size = new System.Drawing.Size(230, 26);
            this.txtFormula1.TabIndex = 7;
            this.txtFormula1.Text = "X+Y+Z";
            // 
            // lblFormula1
            // 
            this.lblFormula1.AutoSize = true;
            this.lblFormula1.Location = new System.Drawing.Point(4, 111);
            this.lblFormula1.Name = "lblFormula1";
            this.lblFormula1.Size = new System.Drawing.Size(68, 20);
            this.lblFormula1.TabIndex = 8;
            this.lblFormula1.Text = "Formula 1";
            // 
            // lblFormula2
            // 
            this.lblFormula2.AutoSize = true;
            this.lblFormula2.Location = new System.Drawing.Point(4, 143);
            this.lblFormula2.Name = "lblFormula2";
            this.lblFormula2.Size = new System.Drawing.Size(68, 20);
            this.lblFormula2.TabIndex = 10;
            this.lblFormula2.Text = "Formula 2";
            // 
            // txtFormula2
            // 
            this.txtFormula2.Location = new System.Drawing.Point(78, 140);
            this.txtFormula2.Name = "txtFormula2";
            this.txtFormula2.Size = new System.Drawing.Size(230, 26);
            this.txtFormula2.TabIndex = 9;
            this.txtFormula2.Text = "(X+Y) * Z";
            // 
            // txtResult1
            // 
            this.txtResult1.Location = new System.Drawing.Point(314, 108);
            this.txtResult1.Name = "txtResult1";
            this.txtResult1.Size = new System.Drawing.Size(110, 26);
            this.txtResult1.TabIndex = 11;
            // 
            // txtResult2
            // 
            this.txtResult2.Location = new System.Drawing.Point(314, 140);
            this.txtResult2.Name = "txtResult2";
            this.txtResult2.Size = new System.Drawing.Size(110, 26);
            this.txtResult2.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(436, 247);
            this.Controls.Add(this.txtResult2);
            this.Controls.Add(this.txtResult1);
            this.Controls.Add(this.lblFormula2);
            this.Controls.Add(this.txtFormula2);
            this.Controls.Add(this.lblFormula1);
            this.Controls.Add(this.txtFormula1);
            this.Controls.Add(this.txtZ);
            this.Controls.Add(this.txtY);
            this.Controls.Add(this.txtX);
            this.Controls.Add(this.lblZ);
            this.Controls.Add(this.lblY);
            this.Controls.Add(this.lblX);
            this.Controls.Add(this.btnCalc);
            this.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Label lblX;
        private System.Windows.Forms.Label lblY;
        private System.Windows.Forms.Label lblZ;
        private System.Windows.Forms.TextBox txtX;
        private System.Windows.Forms.TextBox txtY;
        private System.Windows.Forms.TextBox txtZ;
        private System.Windows.Forms.TextBox txtFormula1;
        private System.Windows.Forms.Label lblFormula1;
        private System.Windows.Forms.Label lblFormula2;
        private System.Windows.Forms.TextBox txtFormula2;
        private System.Windows.Forms.TextBox txtResult1;
        private System.Windows.Forms.TextBox txtResult2;
    }
}

