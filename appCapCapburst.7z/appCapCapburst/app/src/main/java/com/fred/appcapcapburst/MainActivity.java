package com.fred.appcapcapburst;

import androidx.annotation.AnyThread;
import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.WorkerThread;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.location.Location;
import android.location.LocationManager;
import android.media.Image;
import android.media.ImageReader;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.util.Log;
import android.util.Size;
import android.view.OrientationEventListener;
import android.view.Surface;
import android.widget.ImageButton;
import android.widget.ImageView;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class MainActivity extends AppCompatActivity implements Handler.Callback {

    //
    private static final String TAG = "MainActivity";
    private static final int REQUEST_PERMISSION_CODE = 1;

    ArrayList<String> REQUIRED_PERMISSIONS = new ArrayList<>(Arrays.asList(
            android.Manifest.permission.CAMERA,
            android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
            android.Manifest.permission.ACCESS_FINE_LOCATION));

    //
    private static final int MSG_OPEN_CAMERA = 1;
    private static final int MSG_CLOSE_CAMERA = 2;
    private static final int MSG_CREATE_SESSION = 3;
    private static final int MSG_CLOSE_SESSION = 4;
    private static final int MSG_SET_PREVIEW_SIZE = 5;
    private static final int MSG_START_PREVIEW = 6;

    private static final int MSG_STOP_PREVIEW = 7;
    private static final int MSG_SET_IMAGE_SIZE = 8;
    private static final int MSG_CAPTURE_IMAGE = 9;
    private static final int MSG_CAPTURE_IMAGE_BURST = 10;
    private static final int MSG_START_CAPTURE_IMAGE_CONTINUOUSLY = 11;
    private static final int MSG_CREATE_REQUEST_BUILDERS = 12;

    private static final int MAX_PREVIEW_WIDTH = 1440;
    private static final int MAX_PREVIEW_HEIGHT = 1080;
    private static final int MAX_IMAGE_WIDTH = 4032;
    private static final int MAX_IMAGE_HEIGHT = 3024;

    //
    private Handler mainHandler = new Handler(getMainLooper());


    private CameraManager cameraManager;
    //private CameraPreview cameraPreview;
    private ImageView thumbnailView;
    private ImageButton captureImageButton;
    private BlockingQueue<CaptureResult> CaptureResults = new LinkedBlockingQueue<>();

    private HandlerThread cameraThread;
    private Handler cameraHandler;

    private String frontCameraId;
    private CameraCharacteristics frontCameraCharacteristics;
    private String backCameraId;
    private CameraCharacteristics backCameraCharacteristics;

    private Surface previewSurface;
    private ImageReader previewDataImageReader;
    private Surface previewDataSurface;

    private SettableFuture<CameraDevice> cameraDeviceFuture;
    private SettableFuture<CameraCharacteristics> cameraCharacteristicsFuture;
    private SettableFuture<CameraCaptureSession> captureSessionFuture;
    private SettableFuture<SurfaceTexture> previewSurfaceTextureFuture;

    private ImageReader jpegImageReader;
    private Surface jpegSurface;

    private CaptureRequest previewImageRequestBuilder;
    private CaptureRequest captureImageRequestBuilder;

    @Override
    public boolean handleMessage(@NonNull Message message) {

        switch (message.what) {

            case MSG_OPEN_CAMERA:
                Log.d(TAG, "Handle message: MSG_OPEN_CAMERA");
                cameraDeviceFuture = new SettableFuture();
                cameraCharacteristicsFuture = new SettableFuture();
                String cameraId = (String) message.obj;

            default:
                break;
        }


        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onResume() {
        super.onResume();
//        deviceOrientationListener.enable()
//        if (checkRequiredPermissions()) {
//            val cameraId = backCameraId ?: frontCameraId!!
//                    openCamera(cameraId)
//            createCaptureRequestBuilders()
//            setPreviewSize(MAX_PREVIEW_WIDTH, MAX_PREVIEW_HEIGHT)
//            setImageSize(MAX_IMAGE_WIDTH, MAX_IMAGE_HEIGHT)
//            createSession()
//            startPreview()
//        }
    }

    @Override
    protected void onPause() {
        super.onPause();
//        deviceOrientationListener.disable()
//        closeCamera()
//        previewDataImageReader?.close()
//        jpegImageReader?.close()
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
//        stopCameraThread()
//        mediaActionSound.release()
    }

    private void startCameraThread() {
        cameraThread = new HandlerThread("CameraThread");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper(), this);
    }

    private void stopCameraThread() {
        cameraThread.quitSafely();
        cameraThread = null;
        cameraHandler = null;
    }

    @MainThread
    private void openCamera(String cameraId) {
        cameraHandler.obtainMessage(MSG_OPEN_CAMERA, cameraId).sendToTarget();
    }

    @MainThread
    private void switchCamera() {
//        val cameraDevice = cameraDeviceFuture?.get()
//        val oldCameraId = cameraDevice?.id
//        val newCameraId = if (oldCameraId == frontCameraId) backCameraId else frontCameraId
//        if (newCameraId != null) {
//            closeCamera()
//            openCamera(newCameraId)
//            createCaptureRequestBuilders()
//            setPreviewSize(MAX_PREVIEW_WIDTH, MAX_PREVIEW_HEIGHT)
//            setImageSize(MAX_IMAGE_WIDTH, MAX_IMAGE_HEIGHT)
//            createSession()
//            startPreview()
//        }
    }

    @MainThread
    private void closeCamera() {
        cameraHandler.sendEmptyMessage(MSG_CLOSE_CAMERA);
    }

    @MainThread
    private void setPreviewSize(int maxWidth, int maxHeight) {
        cameraHandler.obtainMessage(MSG_SET_PREVIEW_SIZE, maxWidth, maxHeight).sendToTarget();
    }

    @MainThread
    private void setImageSize(int maxWidth, int maxHeight) {
        cameraHandler.obtainMessage(MSG_SET_IMAGE_SIZE, maxWidth, maxHeight).sendToTarget();
    }

    @MainThread
    private void createSession() {
        cameraHandler.sendEmptyMessage(MSG_CREATE_SESSION);
    }

    @MainThread
    private void closeSession() {
        cameraHandler.sendEmptyMessage(MSG_CLOSE_SESSION);
    }

    @MainThread
    private void createCaptureRequestBuilders() {
        cameraHandler.sendEmptyMessage(MSG_CREATE_REQUEST_BUILDERS);
    }

    @MainThread
    private void startPreview() {
        cameraHandler.sendEmptyMessage(MSG_START_PREVIEW);
    }

    @MainThread
    private void stopPreview() {
        cameraHandler.sendEmptyMessage(MSG_STOP_PREVIEW);
    }

    @MainThread
    private void captureImage() {
        cameraHandler.sendEmptyMessage(MSG_CAPTURE_IMAGE);
    }

    @MainThread
    private void captureImageBurst(int burstNumber) {
        cameraHandler.obtainMessage(MSG_CAPTURE_IMAGE_BURST, burstNumber, 0).sendToTarget();
    }

    @MainThread
    private void startCaptureImageContinuously() {
        cameraHandler.sendEmptyMessage(MSG_START_CAPTURE_IMAGE_CONTINUOUSLY);
    }

    @MainThread
    private void stopCaptureImageContinuously() {
        // Restart preview to stop the continuous image capture.
        startPreview();
    }

//    @WorkerThread
//    private Size getOptimalSize(CameraCharacteristics cameraCharacteristics, Class<*> clazz, int maxWidth, int maxHeight) {
//        var streamConfigurationMap = cameraCharacteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
//        var supportedSizes = streamConfigurationMap.getOutputSizes(clazz);
//        return getOptimalSize(supportedSizes, maxWidth, maxHeight);
//    }
//
//    @AnyThread
//    private Size getOptimalSize(Array<Size> supportedSizes, int maxWidth, int maxHeight) {
//        float aspectRatio = (float)maxWidth / (float)maxHeight;
//        if (supportedSizes != null) {
//            foreach (Size size in supportedSizes) {
//                if (size.width.toFloat() / size.height == aspectRatio && size.height <= maxHeight && size.width <= maxWidth) {
//                    return size;
//                }
//            }
//        }
//        return null;
//    }

    private int getDisplayRotation(CameraCharacteristics cameraCharacteristics) {
        int rotation = getWindowManager().getDefaultDisplay().getRotation();
        int degrees = 0;

        return degrees;
    }

    private int getJpegOrientation(CameraCharacteristics cameraCharacteristics, int deviceOrientation) {
        int myDeviceOrientation = deviceOrientation;
        if (myDeviceOrientation == android.view.OrientationEventListener.ORIENTATION_UNKNOWN) {
            return 0;
        }
        int sensorOrientation = cameraCharacteristics.get(CameraCharacteristics.SENSOR_ORIENTATION);

        // Round device orientation to a multiple of 90
        myDeviceOrientation = (myDeviceOrientation + 45) / 90 * 90;

        // Reverse device orientation for front-facing cameras
        boolean facingFront = cameraCharacteristics.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT;
        if (facingFront) {
            myDeviceOrientation = -myDeviceOrientation;
        }

        // Calculate desired JPEG orientation relative to camera orientation to make
        // the image upright relative to the device orientation
        return (sensorOrientation + myDeviceOrientation + 360) % 360;
    }

    private CameraCharacteristics getCameraCharacteristics(String cameraId) {

        CameraCharacteristics tmpCameraCharacteristics = null;

        if (cameraId == frontCameraId) {
            tmpCameraCharacteristics = frontCameraCharacteristics;
        } else if (cameraId == backCameraId) {
            tmpCameraCharacteristics = backCameraCharacteristics;
        }
        return tmpCameraCharacteristics;
    }

    /**
     * Returns a thumbnail bitmap from the specified jpeg file.
     */
//    @WorkerThread
//    private Bitmap getThumbnail(String jpegPath) {
//        val exifInterface = ExifInterface(jpegPath)
//        val orientationFlag = exifInterface.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
//        val orientation = when (orientationFlag) {
//            ExifInterface.ORIENTATION_NORMAL -> 0.0F
//            ExifInterface.ORIENTATION_ROTATE_90 -> 90.0F
//            ExifInterface.ORIENTATION_ROTATE_180 -> 180.0F
//            ExifInterface.ORIENTATION_ROTATE_270 -> 270.0F
//            else -> 0.0F
//        }
//
//        var thumbnail = if (exifInterface.hasThumbnail()) {
//            exifInterface.thumbnailBitmap
//        } else {
//            val options = BitmapFactory.Options()
//            options.inSampleSize = 16
//            BitmapFactory.decodeFile(jpegPath, options)
//        }
//
//        if (orientation != 0.0F && thumbnail != null) {
//            val matrix = Matrix()
//            matrix.setRotate(orientation)
//            thumbnail = Bitmap.createBitmap(thumbnail, 0, 0, thumbnail.width, thumbnail.height, matrix, true)
//        }
//
//        return thumbnail
//    }
    @WorkerThread
    private Location getLocation() {

        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (locationManager != null) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return null;
            }
            return locationManager.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER);
        }
        return null;
    }

    /**
     * Checks if all required permissions are granted and requests denied permissions.
     *
     * @return Returns true if all required permissions are granted.
     */
    private boolean checkRequiredPermissions() {

        ArrayList<String>deniedPermissions = new ArrayList<>();

    }


    private final CameraDevice.StateCallback CameraStateCallback = new CameraDevice.StateCallback() {
        @Override
        public void onOpened(@NonNull CameraDevice camera) {
            cameraDeviceFuture.set(camera);
            cameraCharacteristicsFuture.set(getCameraCharacteristics(camera.getId()));
        }

        @Override
        public void onDisconnected(@NonNull CameraDevice cameraDevice) {
            cameraDeviceFuture.set(cameraDevice);
            closeCamera();
        }

        @Override
        public void onError(@NonNull CameraDevice cameraDevice, int i) {
            cameraDevice.close();
            cameraDevice=null;
        }
    };



    private final ImageReader.OnImageAvailableListener OnJpegImageAvailableListener
            = new ImageReader.OnImageAvailableListener() {

        @Override
        public void onImageAvailable(ImageReader imageReader) {

        }
    };


}