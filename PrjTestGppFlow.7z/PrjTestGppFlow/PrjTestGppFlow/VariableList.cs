﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrjTestGppFlow
{
    public class BaseVariable
    {
        public string VariableName;
        public int VariableId;
    }


    public class VariableList
    {




    }
}
