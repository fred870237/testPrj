﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrjTestGppFlow
{
    public class ClsLight : BaseObject
    {
        public ClsLight(string name, string type, int id)
        {
            this.ObjectName = name;
            this.ObjectType = type;
            this.ObjectId = id;
        }

        public override void Initial()
        {
            Console.WriteLine("[ClsLight Initial]");
        }

        public override void Open()
        {
            Console.WriteLine("[ClsLight Open]");
        }

        public override void Close()
        {
            Console.WriteLine("[ClsLight Close]");
        }

        public override void Run(string action, string[] parameters, string[] data)
        {
            string msg = string.Format("***** {0} {1} {2} {3}" + Environment.NewLine,
                this.ObjectName, this.ObjectType, this.ObjectId, action);

            Console.WriteLine(msg);
        }

        public void SetBrightness(int o_intensity)
        {
            Console.WriteLine("[ClsLight SetBrightness] : " + "set intensity " + o_intensity);
        }
    }
}
