﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrjTestGppFlow
{
    public class BaseObject
    {
        public string ObjectName;
        public int ObjectId;
        public string ObjectType;

        public virtual void Initial()
        {
            
        }

        public virtual void Open()
        {

        }

        public virtual void Close()
        {

        }
        public virtual void Run(string action, string [] parameters, string [] data)
        {

        }

    }


    public class DeviceList
    {
        public BaseObject m_BaseObject;

        public DeviceList()
        {
            
        }

    }
}
