﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrjTestGppFlow
{
    class ClsControl : BaseObject
    {
        public ClsControl(string name, string type, int id)
        {
            this.ObjectName = name;
            this.ObjectType = type;
            this.ObjectId = id;
        }

        public override void Run(string action, string[] parameters, string[] data)
        {
            string msg = string.Format("***** {0} {1} {2} {3}" + Environment.NewLine,
                this.ObjectName, this.ObjectType, this.ObjectId, action);

            Console.WriteLine(msg);
        }



    }
}
