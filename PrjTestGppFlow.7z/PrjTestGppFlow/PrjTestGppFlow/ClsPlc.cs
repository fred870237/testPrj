﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrjTestGppFlow
{
    public class ClsPlc : BaseObject
    {
        public string Ip;
        
        public ClsPlc(string name, string type, int id)
        {
            this.ObjectName = name;
            this.ObjectType = type;
            this.ObjectId = id;
        }

        public override void Initial()
        {
            Console.WriteLine("[ClsPlc Initial] : set plc parametets");
        }

        public override void Open()
        {
            Console.WriteLine("[ClsPlc Open] : open plc");
        }

        public override void Close()
        {
            Console.WriteLine("[ClsPlc Close] : close plc");
        }

        public override void Run(string action, string [] parameters, string [] data)
        {

            string msg = string.Format("***** {0} {1} {2} {3}" + Environment.NewLine,
                this.ObjectName, this.ObjectType, this.ObjectId, action);

            Console.WriteLine(msg);

            //if (action == "SetDevice")
            //{
            //    this._setDevive(parameters[0], Convert.ToInt32(data[0]));
            //}
            //else if (action == "GetDevice")
            //{
            //    int tempData = 0;
            //    this._getDevice(parameters[0], ref tempData);
            //    data[0] = tempData.ToString();
            //}

        }

        private void _setDevive(string o_device, int o_value)
        {
            Console.WriteLine("[ClsPlc SetDevice] : write " + o_device + " to " + o_value);
        }

        public void _getDevice(string o_device, ref int o_value)
        {
            Console.WriteLine("[ClsPlc ReadDevice] : read " + o_value + " from " + o_device);
        }
    }
}
