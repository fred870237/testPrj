﻿
namespace UR_Robot
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.txb_ip = new System.Windows.Forms.TextBox();
            this.btn_connect = new System.Windows.Forms.Button();
            this.btn_pwOn = new System.Windows.Forms.Button();
            this.btn_pwOff = new System.Windows.Forms.Button();
            this.btn_bkRelease = new System.Windows.Forms.Button();
            this.btn_disconnect = new System.Windows.Forms.Button();
            this.btn_move = new System.Windows.Forms.Button();
            this.btn_stop = new System.Windows.Forms.Button();
            this.txb_moveInstruct = new System.Windows.Forms.TextBox();
            this.btn_readRoute = new System.Windows.Forms.Button();
            this.btn_runRoute = new System.Windows.Forms.Button();
            this.btn_revise = new System.Windows.Forms.Button();
            this.btn_home = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown5 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown6 = new System.Windows.Forms.NumericUpDown();
            this.btn_moveNum = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).BeginInit();
            this.SuspendLayout();
            // 
            // txb_ip
            // 
            this.txb_ip.Location = new System.Drawing.Point(12, 12);
            this.txb_ip.Name = "txb_ip";
            this.txb_ip.Size = new System.Drawing.Size(101, 22);
            this.txb_ip.TabIndex = 0;
            this.txb_ip.Text = "192.168.1.2";
            // 
            // btn_connect
            // 
            this.btn_connect.Location = new System.Drawing.Point(119, 9);
            this.btn_connect.Name = "btn_connect";
            this.btn_connect.Size = new System.Drawing.Size(74, 28);
            this.btn_connect.TabIndex = 1;
            this.btn_connect.Text = "Connect";
            this.btn_connect.UseVisualStyleBackColor = true;
            this.btn_connect.Click += new System.EventHandler(this.btn_connect_Click);
            // 
            // btn_pwOn
            // 
            this.btn_pwOn.Location = new System.Drawing.Point(12, 40);
            this.btn_pwOn.Name = "btn_pwOn";
            this.btn_pwOn.Size = new System.Drawing.Size(74, 28);
            this.btn_pwOn.TabIndex = 2;
            this.btn_pwOn.Text = "Power On";
            this.btn_pwOn.UseVisualStyleBackColor = true;
            this.btn_pwOn.Click += new System.EventHandler(this.Btn_pwOn_Click);
            // 
            // btn_pwOff
            // 
            this.btn_pwOff.Location = new System.Drawing.Point(12, 74);
            this.btn_pwOff.Name = "btn_pwOff";
            this.btn_pwOff.Size = new System.Drawing.Size(74, 28);
            this.btn_pwOff.TabIndex = 3;
            this.btn_pwOff.Text = "Power Off";
            this.btn_pwOff.UseVisualStyleBackColor = true;
            this.btn_pwOff.Click += new System.EventHandler(this.Btn_pwOff_Click);
            // 
            // btn_bkRelease
            // 
            this.btn_bkRelease.Location = new System.Drawing.Point(92, 74);
            this.btn_bkRelease.Name = "btn_bkRelease";
            this.btn_bkRelease.Size = new System.Drawing.Size(101, 28);
            this.btn_bkRelease.TabIndex = 4;
            this.btn_bkRelease.Text = "Brake Release";
            this.btn_bkRelease.UseVisualStyleBackColor = true;
            this.btn_bkRelease.Click += new System.EventHandler(this.Btn_bkRelease_Click);
            // 
            // btn_disconnect
            // 
            this.btn_disconnect.Location = new System.Drawing.Point(119, 40);
            this.btn_disconnect.Name = "btn_disconnect";
            this.btn_disconnect.Size = new System.Drawing.Size(74, 28);
            this.btn_disconnect.TabIndex = 5;
            this.btn_disconnect.Text = "Disconncet";
            this.btn_disconnect.UseVisualStyleBackColor = true;
            this.btn_disconnect.Click += new System.EventHandler(this.Btn_disconnect_Click);
            // 
            // btn_move
            // 
            this.btn_move.Location = new System.Drawing.Point(12, 124);
            this.btn_move.Name = "btn_move";
            this.btn_move.Size = new System.Drawing.Size(74, 28);
            this.btn_move.TabIndex = 6;
            this.btn_move.Text = "Move";
            this.btn_move.UseVisualStyleBackColor = true;
            this.btn_move.Click += new System.EventHandler(this.Btn_move_Click);
            // 
            // btn_stop
            // 
            this.btn_stop.Location = new System.Drawing.Point(12, 158);
            this.btn_stop.Name = "btn_stop";
            this.btn_stop.Size = new System.Drawing.Size(74, 28);
            this.btn_stop.TabIndex = 7;
            this.btn_stop.Text = "Stop";
            this.btn_stop.UseVisualStyleBackColor = true;
            this.btn_stop.Click += new System.EventHandler(this.Btn_stop_Click);
            // 
            // txb_moveInstruct
            // 
            this.txb_moveInstruct.Location = new System.Drawing.Point(92, 127);
            this.txb_moveInstruct.Name = "txb_moveInstruct";
            this.txb_moveInstruct.Size = new System.Drawing.Size(415, 22);
            this.txb_moveInstruct.TabIndex = 8;
            this.txb_moveInstruct.Text = "movel(p[-0.843, -0.017, 0.386, 2.21, 2.22, 0.0038],a=0.3, v=0.1, t=0, r=0)";
            // 
            // btn_readRoute
            // 
            this.btn_readRoute.Location = new System.Drawing.Point(12, 211);
            this.btn_readRoute.Name = "btn_readRoute";
            this.btn_readRoute.Size = new System.Drawing.Size(74, 28);
            this.btn_readRoute.TabIndex = 9;
            this.btn_readRoute.Text = "Read Route";
            this.btn_readRoute.UseVisualStyleBackColor = true;
            this.btn_readRoute.Click += new System.EventHandler(this.Btn_readRoute_Click);
            // 
            // btn_runRoute
            // 
            this.btn_runRoute.Location = new System.Drawing.Point(92, 211);
            this.btn_runRoute.Name = "btn_runRoute";
            this.btn_runRoute.Size = new System.Drawing.Size(74, 28);
            this.btn_runRoute.TabIndex = 10;
            this.btn_runRoute.Text = "Run Route";
            this.btn_runRoute.UseVisualStyleBackColor = true;
            this.btn_runRoute.Click += new System.EventHandler(this.Btn_runRoute_Click);
            // 
            // btn_revise
            // 
            this.btn_revise.Location = new System.Drawing.Point(12, 264);
            this.btn_revise.Name = "btn_revise";
            this.btn_revise.Size = new System.Drawing.Size(74, 28);
            this.btn_revise.TabIndex = 12;
            this.btn_revise.Text = "Revise";
            this.btn_revise.UseVisualStyleBackColor = true;
            this.btn_revise.Click += new System.EventHandler(this.Btn_revise_Click);
            // 
            // btn_home
            // 
            this.btn_home.Location = new System.Drawing.Point(92, 155);
            this.btn_home.Name = "btn_home";
            this.btn_home.Size = new System.Drawing.Size(74, 28);
            this.btn_home.TabIndex = 13;
            this.btn_home.Text = "Home";
            this.btn_home.UseVisualStyleBackColor = true;
            this.btn_home.Click += new System.EventHandler(this.Btn_home_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(255, 189);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(64, 22);
            this.button1.TabIndex = 14;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(357, 186);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(74, 25);
            this.button2.TabIndex = 15;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.DecimalPlaces = 3;
            this.numericUpDown1.Location = new System.Drawing.Point(44, 309);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(90, 22);
            this.numericUpDown1.TabIndex = 16;
            this.numericUpDown1.Value = new decimal(new int[] {
            842,
            0,
            0,
            -2147483648});
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.DecimalPlaces = 3;
            this.numericUpDown2.Location = new System.Drawing.Point(44, 337);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown2.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(90, 22);
            this.numericUpDown2.TabIndex = 16;
            this.numericUpDown2.Value = new decimal(new int[] {
            17,
            0,
            0,
            -2147483648});
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.DecimalPlaces = 3;
            this.numericUpDown3.Location = new System.Drawing.Point(44, 365);
            this.numericUpDown3.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown3.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(90, 22);
            this.numericUpDown3.TabIndex = 16;
            this.numericUpDown3.Value = new decimal(new int[] {
            386,
            0,
            0,
            0});
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.DecimalPlaces = 3;
            this.numericUpDown4.Location = new System.Drawing.Point(140, 309);
            this.numericUpDown4.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.numericUpDown4.Minimum = new decimal(new int[] {
            360,
            0,
            0,
            -2147483648});
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(90, 22);
            this.numericUpDown4.TabIndex = 16;
            this.numericUpDown4.Value = new decimal(new int[] {
            221,
            0,
            0,
            131072});
            // 
            // numericUpDown5
            // 
            this.numericUpDown5.DecimalPlaces = 3;
            this.numericUpDown5.Location = new System.Drawing.Point(140, 337);
            this.numericUpDown5.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.numericUpDown5.Minimum = new decimal(new int[] {
            360,
            0,
            0,
            -2147483648});
            this.numericUpDown5.Name = "numericUpDown5";
            this.numericUpDown5.Size = new System.Drawing.Size(90, 22);
            this.numericUpDown5.TabIndex = 16;
            this.numericUpDown5.Value = new decimal(new int[] {
            222,
            0,
            0,
            131072});
            // 
            // numericUpDown6
            // 
            this.numericUpDown6.DecimalPlaces = 3;
            this.numericUpDown6.Location = new System.Drawing.Point(140, 365);
            this.numericUpDown6.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.numericUpDown6.Minimum = new decimal(new int[] {
            360,
            0,
            0,
            -2147483648});
            this.numericUpDown6.Name = "numericUpDown6";
            this.numericUpDown6.Size = new System.Drawing.Size(90, 22);
            this.numericUpDown6.TabIndex = 16;
            // 
            // btn_moveNum
            // 
            this.btn_moveNum.Location = new System.Drawing.Point(44, 393);
            this.btn_moveNum.Name = "btn_moveNum";
            this.btn_moveNum.Size = new System.Drawing.Size(74, 28);
            this.btn_moveNum.TabIndex = 6;
            this.btn_moveNum.Text = "Move";
            this.btn_moveNum.UseVisualStyleBackColor = true;
            this.btn_moveNum.Click += new System.EventHandler(this.btn_moveNum_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(264, 309);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(74, 28);
            this.button3.TabIndex = 6;
            this.button3.Text = "rx-";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.btn_moveNum_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(344, 309);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(74, 28);
            this.button4.TabIndex = 6;
            this.button4.Text = "rx+";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.btn_moveNum_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(264, 343);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(74, 28);
            this.button5.TabIndex = 6;
            this.button5.Text = "rz-";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.btn_moveNum_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(344, 343);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(74, 28);
            this.button6.TabIndex = 6;
            this.button6.Text = "rz+";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.btn_moveNum_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.numericUpDown6);
            this.Controls.Add(this.numericUpDown5);
            this.Controls.Add(this.numericUpDown3);
            this.Controls.Add(this.numericUpDown4);
            this.Controls.Add(this.numericUpDown2);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn_home);
            this.Controls.Add(this.btn_revise);
            this.Controls.Add(this.btn_runRoute);
            this.Controls.Add(this.btn_readRoute);
            this.Controls.Add(this.txb_moveInstruct);
            this.Controls.Add(this.btn_stop);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btn_moveNum);
            this.Controls.Add(this.btn_move);
            this.Controls.Add(this.btn_disconnect);
            this.Controls.Add(this.btn_bkRelease);
            this.Controls.Add(this.btn_pwOff);
            this.Controls.Add(this.btn_pwOn);
            this.Controls.Add(this.btn_connect);
            this.Controls.Add(this.txb_ip);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txb_ip;
        private System.Windows.Forms.Button btn_connect;
        private System.Windows.Forms.Button btn_pwOn;
        private System.Windows.Forms.Button btn_pwOff;
        private System.Windows.Forms.Button btn_bkRelease;
        private System.Windows.Forms.Button btn_disconnect;
        private System.Windows.Forms.Button btn_move;
        private System.Windows.Forms.Button btn_stop;
        private System.Windows.Forms.TextBox txb_moveInstruct;
        private System.Windows.Forms.Button btn_readRoute;
        private System.Windows.Forms.Button btn_runRoute;
        private System.Windows.Forms.Button btn_revise;
        private System.Windows.Forms.Button btn_home;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.NumericUpDown numericUpDown4;
        private System.Windows.Forms.NumericUpDown numericUpDown5;
        private System.Windows.Forms.NumericUpDown numericUpDown6;
        private System.Windows.Forms.Button btn_moveNum;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
    }
}

