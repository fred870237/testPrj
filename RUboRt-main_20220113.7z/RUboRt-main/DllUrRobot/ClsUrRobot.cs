﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;


namespace DllUrRobot
{
    public class ClsUrRobotCofig
    {
        public string IpAddress;

        public ClsUrRobotCofig()
        {
            this.IpAddress = "192.168.1.2";
        }
    }

    public class ClsUrRobotControl
    {
        private Socket socket29999;
        private Socket socket30003;

        private byte[] dataByte29999 = new byte[1024];
        private byte[] dataByte30003 = new byte[2048];


        public ClsUrRobotControl()
        {
            this.socket29999 = null;
            this.socket30003 = null;

            this.dataByte29999 = new byte[1024];
            this.dataByte30003 = new byte[2048];


        }

        private int _connect29999()
        {
            int iRet = 0;



            return iRet;
        }

        private int _connect30003()
        {
            int iRet = 0;



            return iRet;
        }

        public bool Connect()
        {
            int iRet = 0;

            try
            {
                // _connect30003
                iRet += this._connect30003();


                // _connect29999
                iRet += this._connect29999();


            }
            catch (Exception ex)
            {

            }

 
            if (iRet == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool Disconnect;



    }
}
