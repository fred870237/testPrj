﻿using GPP_Demo.BaseClasses;
using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GPP_Demo
{
    /// <summary>
    /// MainWindow.xaml 的互動邏輯
    /// </summary>
    public partial class MainWindow : Window
    {
        bool isStop = false;
        bool isRunning = false;
        BootConfig bootConfig;
        Dictionary<string, string> data;
        Dictionary<string, BaseElement> ActionElements;
        //Dictionary<string, Func<ExecuteParameters>> ActionFunction;

        public MainWindow()
        {
            InitializeComponent();
            bootConfig = new BootConfig();
            rtbShowLog.Document.Blocks.Clear();
            data = new Dictionary<string, string>();
            ActionElements = new Dictionary<string, BaseElement>();
        }

        private void btnStart_Click(object sender, RoutedEventArgs e)
        {
            Log("_btnStart Click \r\n");
            if (isRunning) { return; }

            try
            {
                isRunning = true;

                Log("Read Recipe.xml \r\n");
                bootConfig = bootConfig.ReadXmlConfig(txtBootPath.Text);

                InitialElements();
                isStop = false;
                ExecuteFlowList();

            }
            catch (Exception)
            {
            }
            finally
            {
                isRunning = false;
            }
        }

        private void InitialElements()
        {
            Log("===== MainWindow Initial Elements =====");

            foreach (var item in bootConfig.elementList)
            {
                try
                {
                    if (ActionElements.ContainsKey(item.name))
                    { }
                    else
                    {
                        Type t = Type.GetType(item.classType);
                        BaseElement tmp = (BaseElement)Activator.CreateInstance(t, false);
                        tmp.Log += this.Log;
                        tmp.Initial(item.parameters);
                        ActionElements.Add(tmp.Name, tmp);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            Log("========== Initial End ==========");
        }

        private void ExecuteFlowList()
        {
            Log("===== MainWindow Execute Flow-List =====");
            int nextIndex = 0;
            BaseElement tmpElement;
            while (isStop == false)
            {
                try
                {
                    if (nextIndex >= bootConfig.flowList.Count)
                    {
                        isStop = true;
                        break;
                    }
                    else if (ActionElements.TryGetValue(bootConfig.flowList[nextIndex].objectName, out tmpElement))
                    {
                        tmpElement.Execute(bootConfig.flowList[nextIndex], ref nextIndex, ref data);
                        nextIndex++;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            Log("========== Execute End ==========");
        }

        private void Log(string logText)
        {
            try
            {
                rtbShowLog.AppendText(logText + "\r\n");
                rtbShowLog.ScrollToEnd();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSaveTest_Click(object sender, RoutedEventArgs e)
        {
            Log("_btnSaveTest Click");

            ///-----------建立測試物件-----------///
            ElementSetting tempSetting;

            BaseIP ip1 = new BaseIP();
            BasePLC plc1 = new BasePLC();
            BaseLight light1 = new BaseLight();
            BaseControl ctrl1 = new BaseControl();

            tempSetting = new ElementSetting();
            tempSetting.name = ip1.Name;
            tempSetting.classType = ip1.GetType().FullName;
            tempSetting.parameters = ip1.GetParameters();
            bootConfig.elementList.Add(tempSetting);
            tempSetting = null;

            tempSetting = new ElementSetting();
            tempSetting.name = plc1.Name;
            tempSetting.classType = plc1.GetType().FullName;
            tempSetting.parameters = plc1.GetParameters();
            bootConfig.elementList.Add(tempSetting);
            tempSetting = null;

            tempSetting = new ElementSetting();
            tempSetting.name = light1.Name;
            tempSetting.classType = light1.GetType().FullName;
            tempSetting.parameters = light1.GetParameters();
            bootConfig.elementList.Add(tempSetting);
            tempSetting = null;

            tempSetting = new ElementSetting();
            tempSetting.name = ctrl1.Name;
            tempSetting.classType = ctrl1.GetType().FullName;
            tempSetting.parameters = ctrl1.GetParameters();
            bootConfig.elementList.Add(tempSetting);
            tempSetting = null;

            ///-----------建立測試流程-----------///
            ExecuteParameters tempFlow;

            tempFlow = new ExecuteParameters();
            tempFlow.objectName = ctrl1.Name;
            tempFlow.command = "SetBuffer";
            tempFlow.parameter1 = "Path";
            tempFlow.parameter2 = "0";
            bootConfig.flowList.Add(tempFlow);
            tempFlow = null;

            tempFlow = new ExecuteParameters();
            tempFlow.objectName = plc1.Name;
            tempFlow.command = "Set";
            tempFlow.parameter1 = "D3060";
            tempFlow.parameter2 = "1";
            bootConfig.flowList.Add(tempFlow);
            tempFlow = null;

            tempFlow = new ExecuteParameters();
            tempFlow.objectName = plc1.Name;
            tempFlow.command = "Get";
            tempFlow.parameter1 = "D3070";
            tempFlow.parameter2 = "1";
            bootConfig.flowList.Add(tempFlow);
            tempFlow = null;

            tempFlow = new ExecuteParameters();
            tempFlow.objectName = plc1.Name;
            tempFlow.command = "Set";
            tempFlow.parameter1 = "D3060";
            tempFlow.parameter2 = "0";
            bootConfig.flowList.Add(tempFlow);
            tempFlow = null;

            tempFlow = new ExecuteParameters();
            tempFlow.objectName = plc1.Name;
            tempFlow.command = "Set";
            tempFlow.parameter1 = "D3090";
            tempFlow.parameter2 = "1";
            bootConfig.flowList.Add(tempFlow);
            tempFlow = null;

            tempFlow = new ExecuteParameters();
            tempFlow.objectName = plc1.Name;
            tempFlow.command = "GetToBuffer";
            tempFlow.parameter1 = "D3096";
            tempFlow.parameter2 = "Path";
            bootConfig.flowList.Add(tempFlow);
            tempFlow = null;

            tempFlow = new ExecuteParameters();
            tempFlow.objectName = plc1.Name;
            tempFlow.command = "Get";
            tempFlow.parameter1 = "D3095";
            tempFlow.parameter2 = "1";
            bootConfig.flowList.Add(tempFlow);
            tempFlow = null;

            tempFlow = new ExecuteParameters();
            tempFlow.objectName = light1.Name;
            tempFlow.command = "SetIntensity";
            tempFlow.parameter1 = "100";
            bootConfig.flowList.Add(tempFlow);
            tempFlow = null;

            tempFlow = new ExecuteParameters();
            tempFlow.objectName = ip1.Name;
            tempFlow.command = "Stop";
            bootConfig.flowList.Add(tempFlow);
            tempFlow = null;

            tempFlow = new ExecuteParameters();
            tempFlow.objectName = ip1.Name;
            tempFlow.command = "Reload";
            tempFlow.parameter1 = "C080EAT02.1";
            bootConfig.flowList.Add(tempFlow);
            tempFlow = null;

            tempFlow = new ExecuteParameters();
            tempFlow.objectName = plc1.Name;
            tempFlow.command = "Get";
            tempFlow.parameter1 = "D3105";
            tempFlow.parameter2 = "1";
            bootConfig.flowList.Add(tempFlow);
            tempFlow = null;

            tempFlow = new ExecuteParameters();
            tempFlow.objectName = ip1.Name;
            tempFlow.command = "Start";
            tempFlow.parameter1 = "true";
            tempFlow.parameter2 = "true";
            bootConfig.flowList.Add(tempFlow);
            tempFlow = null;

            tempFlow = new ExecuteParameters();
            tempFlow.objectName = plc1.Name;
            tempFlow.command = "Set";
            tempFlow.parameter1 = "D3100";
            tempFlow.parameter2 = "1";
            bootConfig.flowList.Add(tempFlow);
            tempFlow = null;

            tempFlow = new ExecuteParameters();
            tempFlow.objectName = plc1.Name;
            tempFlow.command = "Get";
            tempFlow.parameter1 = "D3115";
            tempFlow.parameter2 = "1";
            bootConfig.flowList.Add(tempFlow);
            tempFlow = null;

            tempFlow = new ExecuteParameters();
            tempFlow.objectName = ip1.Name;
            tempFlow.command = "GrabEnd";
            bootConfig.flowList.Add(tempFlow);
            tempFlow = null;

            tempFlow = new ExecuteParameters();
            tempFlow.objectName = plc1.Name;
            tempFlow.command = "Set";
            tempFlow.parameter1 = "D3110";
            tempFlow.parameter2 = "1";
            bootConfig.flowList.Add(tempFlow);
            tempFlow = null;

            tempFlow = new ExecuteParameters();
            tempFlow.objectName = ctrl1.Name;
            tempFlow.command = "NextStep";
            tempFlow.parameter1 = "Buffer#Path;Less;2";
            tempFlow.parameter2 = "-12";
            tempFlow.parameter3 = "1";
            bootConfig.flowList.Add(tempFlow);
            tempFlow = null;

            tempFlow = new ExecuteParameters();
            tempFlow.objectName = plc1.Name;
            tempFlow.command = "Set";
            tempFlow.parameter1 = "D3121";
            tempFlow.parameter2 = "OK";
            bootConfig.flowList.Add(tempFlow);
            tempFlow = null;

            tempFlow = new ExecuteParameters();
            tempFlow.objectName = plc1.Name;
            tempFlow.command = "Set";
            tempFlow.parameter1 = "D3120";
            tempFlow.parameter2 = "1";
            bootConfig.flowList.Add(tempFlow);
            tempFlow = null;

            tempFlow = new ExecuteParameters();
            tempFlow.objectName = plc1.Name;
            tempFlow.command = "Get";
            tempFlow.parameter1 = "D3125";
            tempFlow.parameter2 = "1";
            bootConfig.flowList.Add(tempFlow);
            tempFlow = null;


            bootConfig.WriteXmlConfig(txtBootPath.Text);
        }
    }
}
