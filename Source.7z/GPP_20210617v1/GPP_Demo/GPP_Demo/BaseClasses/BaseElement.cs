﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GPP_Demo.BaseClasses
{
    public delegate void RecordEvent(string Info);
    public class BaseElement
    {
        public event RecordEvent Log;
        public string Name { get; set; }
        public virtual void Initial(List<string> parameters)
        {
            Log(string.Format("{0} not Implement Inittial Function.", Name));
        }
        public virtual List<string> GetParameters()
        {
            Log(string.Format("{0} not Implement GetParameters Function.", Name));
            return new List<string>();
        }
        public virtual void Execute(ExecuteParameters parameters, ref int index, ref Dictionary<string, string> data)
        {
            Log(string.Format("{0} not Implement Execute Function.", Name));
        }

        public void LogEvent(string str)
        {
            Log(str);
        }
    }
}
