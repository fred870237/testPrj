﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GPP_Demo.BaseClasses
{
    public class ExecuteParameters
    {
        public string objectName { get; set; }
        public string command { get; set; }
        public string parameter1 { get; set; }
        public string parameter2 { get; set; }
        public string parameter3 { get; set; }
        public string parameter4 { get; set; }
        public string parameter5 { get; set; }
        public string parameter6 { get; set; }
        public string parameter7 { get; set; }
        public string parameter8 { get; set; }
        public string parameter9 { get; set; }


        public ExecuteParameters()
        {
            command = "";
            parameter1 = "";
            parameter2 = "";
            parameter3 = "";
            parameter4 = "";
            parameter5 = "";
            parameter6 = "";
            parameter7 = "";
            parameter8 = "";
            parameter9 = "";
            objectName = "";
        }
    }
}
