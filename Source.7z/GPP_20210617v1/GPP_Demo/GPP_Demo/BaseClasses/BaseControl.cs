﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GPP_Demo.BaseClasses
{
    public class BaseControl : BaseElement
    {
        public string NextIndex { get; set; }

        public BaseControl()
        {
            Name = "newControl";
            NextIndex = "1";
        }

        public BaseControl(List<string> parameters)
        {
            Name = parameters[0];
            NextIndex = parameters[1];
        }

        public override void Initial(List<string> parameters)
        {
            Name = parameters[0];
            NextIndex = parameters[1];
            LogEvent(string.Format("Inittial Function of {0}.", Name));
        }

        public override List<string> GetParameters()
        {
            List<string> para = new List<string>();
            para.Add(Name);
            para.Add(NextIndex);
            return para;
        }

        public override void Execute(ExecuteParameters parameters, ref int index, ref Dictionary<string, string> data)
        {
            LogEvent(string.Format("Step-{11}.Exeute [{0}] [{1}] [{2},{3},{4},{5},{6},{7},{8},{9},{10}]",
                                    Name,
                                    parameters.command,
                                    parameters.parameter1,
                                    parameters.parameter2,
                                    parameters.parameter3,
                                    parameters.parameter4,
                                    parameters.parameter5,
                                    parameters.parameter6,
                                    parameters.parameter7,
                                    parameters.parameter8,
                                    parameters.parameter9,
                                    index.ToString()));

            if (parameters.command == "NextStep")
            {
                var str = parameters.parameter1.Split(';');
                double a, b;
                /// Get value A 
                if (str[0].Contains("Buffer"))
                {
                    a = Convert.ToDouble(data[str[0].Split('#')[1]]);
                }
                else
                {
                    a = Convert.ToDouble(str[0]);
                }
                /// Get value B
                if (str[2].Contains("Buffer"))
                {
                    b = Convert.ToDouble(data[str[2].Split('#')[1]]);
                }
                else
                {
                    b = Convert.ToDouble(str[2]);
                }
                /// Operator
                if (str[1] == "Big")
                {
                    if (a > b)
                    {
                        index += Convert.ToInt32(parameters.parameter2);
                    }
                    else
                    {
                        index += Convert.ToInt32(parameters.parameter3);
                    }
                }
                else if (str[1] == "Less")
                {
                    if (a < b)
                    {
                        index += Convert.ToInt32(parameters.parameter2);
                    }
                    else
                    {
                        index += Convert.ToInt32(parameters.parameter3);
                    }
                }
                else if (str[1] == "Equal")
                {
                    if (a == b)
                    {
                        index += Convert.ToInt32(parameters.parameter2);
                    }
                    else
                    {
                        index += Convert.ToInt32(parameters.parameter3);
                    }
                }
            }
            else if (parameters.command == "SetBuffer")
            {
                string dataValue;
                if (data.TryGetValue(parameters.parameter1, out dataValue))
                {
                    data[parameters.parameter1] = parameters.parameter2;
                }
                else
                {
                    data.Add(parameters.parameter1, parameters.parameter2);
                }
            }
        }
    }
}
