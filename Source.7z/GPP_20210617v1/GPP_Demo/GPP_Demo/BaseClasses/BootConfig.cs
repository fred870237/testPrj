﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GPP_Demo.BaseClasses
{
    public class BootConfig : ClsConfig <BootConfig>
    {
        public List<ElementSetting> elementList { get; set; }
        public List<ExecuteParameters> flowList { get; set; }
        //public List<BaseElement> elements { get; set; }

        public BootConfig()
        {
            elementList = new List<ElementSetting>();
            flowList = new List<ExecuteParameters>();
            //elements = new List<BaseElement>();
        }

    }
}
