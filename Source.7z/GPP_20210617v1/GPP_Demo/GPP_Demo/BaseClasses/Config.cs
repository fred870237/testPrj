﻿//using GlobalizedPropertyGrid;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Net;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace GPP_Demo.BaseClasses
{
    public class ClsConfig<T> //: GlobalizedObject
    {
        public String Update;
        public String Version;

        public T ReadXmlConfig(String configFileName)
        {
            XmlSerializer xmlSerializer = null;
            T tempConfig;
            try
            {
                if (!File.Exists(configFileName))
                {
                    this.WriteXmlConfig(configFileName);
                }
                // Open and read a crypto-xml file.
                using (FileStream fileStream = new FileStream(configFileName, FileMode.Open))
                using (XmlTextReader xmlTextReader = new XmlTextReader(fileStream))
                {
                    xmlSerializer = new XmlSerializer(typeof(T));
                    tempConfig = (T)xmlSerializer.Deserialize(xmlTextReader);

                    fileStream.Close();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("[ReadXmlConfig]" + ex.Message);
            }
            finally
            {
                if (xmlSerializer != null)
                {
                    xmlSerializer = null;
                }
            }
            return tempConfig;
        }

        public T ReadJsonConfig(String configFileName)
        {
            try
            {
                return JsonConvert.DeserializeObject<T>(configFileName);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            { }
        }

        public void WriteXmlConfig(String configFileName)
        {
            XmlSerializer xmlSerializer = null;
            try
            {
                if (!File.Exists(configFileName))
                {
                    configFileName = configFileName.Replace("\\\\", "/").Replace("\\", "/");
                    int index = configFileName.LastIndexOf("/");
                    Directory.CreateDirectory(configFileName.Substring(0, index));
                }
                // Write config value into xml.
                using (FileStream fileStream = new FileStream(configFileName, FileMode.Create))
                {
                    xmlSerializer = new XmlSerializer(typeof(T));
                    xmlSerializer.Serialize(fileStream, this);
                    fileStream.Close();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("[WriteXmlConfig]" + ex.Message);
            }
            finally
            {
                if (xmlSerializer != null)
                {
                    xmlSerializer = null;
                }
            }
        }

        public void WriteJsonConfig(String configFileName)
        {
            try
            {
                if (!File.Exists(configFileName))
                {
                    int index = configFileName.LastIndexOf("/");
                    Directory.CreateDirectory(configFileName.Substring(0, index));
                }                // Write config value into xml.
                using (StreamWriter fileStream = new StreamWriter(configFileName))
                {
                    fileStream.Close();
                    string json = JsonConvert.SerializeObject(this);
                    fileStream.Write(json);
                    fileStream.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            { }
        }

        public string ToXmlString(string newRootTag = "",
                                  string removeTagName = "")
        {
            try
            {
                string rtnStr = "";
                using (var stringwriter = new Utf8StringWriter())
                {
                    var xmlSerializer = new XmlSerializer(typeof(T));

                    var ns = new XmlSerializerNamespaces();
                    ns.Add("", "");

                    xmlSerializer.Serialize(stringwriter, this, ns);

                    rtnStr = stringwriter.ToString();
                }
                ///-----------------
                if (newRootTag != "")
                {
                    rtnStr = rtnStr.Replace(typeof(T).Name, newRootTag);
                }
                ///-----------------
                if (removeTagName != "")
                {
                    rtnStr = rtnStr.Replace("<" + removeTagName + ">", "")
                                   .Replace("</" + removeTagName + ">", "")
                                   .Replace("<" + removeTagName + "/>", "");
                }
                return rtnStr;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public string ToJsonString()
        {
            return JsonConvert.SerializeObject(this);
        }

        public string InXmlTagText(ref string xmlText, string tagName)
        {
            string rtnText = "";
            try
            {
                int startIndex = xmlText.LastIndexOf(string.Format("<{0}>", tagName));
                int endIndex = xmlText.LastIndexOf(string.Format("</{0}>", tagName));
                if (startIndex >= 0 || endIndex >= 0)
                {
                    rtnText = xmlText.Substring(startIndex, endIndex - startIndex);
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show("[InXmlTagText]" + ex.Message);
            }
            return rtnText.Replace(string.Format("<{0}>", tagName), "");
        }

        public string InXmlTagText(string xmlText, string tagName)
        {
            string rtnText = "";
            try
            {
                int startIndex = xmlText.LastIndexOf(string.Format("<{0}>", tagName));
                int endIndex = xmlText.LastIndexOf(string.Format("</{0}>", tagName));
                if (startIndex >= 0 || endIndex >= 0)
                {
                    rtnText = xmlText.Substring(startIndex, endIndex - startIndex);
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show("[InXmlTagText]" + ex.Message);
            }
            return rtnText.Replace(string.Format("<{0}>", tagName), "");
        }

    }

    public class Utf8StringWriter : StringWriter
    {
        public override Encoding Encoding => Encoding.UTF8;
    }

}
