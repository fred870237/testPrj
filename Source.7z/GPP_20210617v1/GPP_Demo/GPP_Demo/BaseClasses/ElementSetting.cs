﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GPP_Demo.BaseClasses
{
    public class ElementSetting
    {
        public string classType { get; set; }
        public string name { get; set; }
        public List<string> parameters { get; set; }


        public ElementSetting()
        {
            name = "";
            classType = "";
            parameters = new List<string>();
        }
    }
}
