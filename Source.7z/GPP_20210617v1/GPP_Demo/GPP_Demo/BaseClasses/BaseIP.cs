﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GPP_Demo.BaseClasses
{
    public class BaseIP : BaseElement
    {
        public bool Camera { get; set; }

        public BaseIP()
        {
            Name = "newIP";
            Camera = true;
        }

        public BaseIP(List<string> parameters)
        {
            Name = parameters[0];
            Camera = Convert.ToBoolean(parameters[1]);
        }

        public override void Initial(List<string> parameters)
        {
            Name = parameters[0];
            Camera = Convert.ToBoolean(parameters[1]);
            LogEvent(string.Format("Inittial Function of {0}.", Name));
        }


        public override List<string> GetParameters()
        {
            List<string> para = new List<string>();
            para.Add(Name);
            para.Add(Camera.ToString());
            return para;
        }

        public override void Execute(ExecuteParameters parameters, ref int index, ref Dictionary<string, string> data)
        {
            LogEvent(string.Format("Step-{11}.Exeute [{0}] [{1}] [{2},{3},{4},{5},{6},{7},{8},{9},{10}]",
                                    Name,
                                    parameters.command,
                                    parameters.parameter1,
                                    parameters.parameter2,
                                    parameters.parameter3,
                                    parameters.parameter4,
                                    parameters.parameter5,
                                    parameters.parameter6,
                                    parameters.parameter7,
                                    parameters.parameter8,
                                    parameters.parameter9,
                                    index.ToString()));
        }
    }
}
