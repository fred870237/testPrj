﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrjTestGppFlow
{
    public class ClsLight : BaseObject
    {
        public override void Initial()
        {
            Console.WriteLine("[ClsLight Initial]");
        }

        public override void Open()
        {
            Console.WriteLine("[ClsLight Open]");
        }

        public override void Close()
        {
            Console.WriteLine("[ClsLight Close]");
        }

        public void SetBrightness(int o_intensity)
        {
            Console.WriteLine("[ClsLight SetBrightness] : " + "set intensity " + o_intensity);
        }
    }
}
