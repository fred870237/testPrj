﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrjTestGppFlow
{
    public class ClsLight : IBaseObject
    {
        public string Initial()
        {
            Console.WriteLine("[ClsLight Initial]");
            return "ClsLight Initial";
        }

        public string Open()
        {
            Console.WriteLine("[ClsLight Open]");
            return "ClsLight Open";
        }

        public string Close()
        {
            Console.WriteLine("[ClsLight Close]");
            return "ClsLight Close";
        }

        public void SetBrightness(int o_intensity)
        {
            Console.WriteLine("[ClsLight SetBrightness] : " + "set intensity " + o_intensity);
        }
    }
}
