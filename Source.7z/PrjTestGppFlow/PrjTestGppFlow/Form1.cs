﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace PrjTestGppFlow
{
    public partial class Form1 : Form
    {
        private ProcessCore g_ProcessCore;

        public Form1()
        {
            InitializeComponent();
        }

        private void threadToDeQueue()
        {

        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            string filePath = ".\\testXml001.xml";

            GppProcessCore temp_GppProcessCore = new GppProcessCore();

            // DeviceList
            




            // FlowList
            Array.Resize(ref temp_GppProcessCore.CoreFlowList, 1);
            temp_GppProcessCore.CoreFlowList[0] = new FlowList();
            temp_GppProcessCore.CoreFlowList[0].id = 0;
            temp_GppProcessCore.CoreFlowList[0].loopCnt = "2";
                
            //
            Array.Resize(ref temp_GppProcessCore.CoreFlowList[0].Level1List, 2);

            //
            temp_GppProcessCore.CoreFlowList[0].Level1List[0] = new ClsLevel1();
            temp_GppProcessCore.CoreFlowList[0].Level1List[0].Type = "PLC";
            temp_GppProcessCore.CoreFlowList[0].Level1List[0].Action = "Initial";
            temp_GppProcessCore.CoreFlowList[0].Level1List[0].WaitTime = 3000;

            Array.Resize(ref temp_GppProcessCore.CoreFlowList[0].Level1List[0].Parameters, 5);
            temp_GppProcessCore.CoreFlowList[0].Level1List[0].Parameters[0] = "192.168.0.1";
            temp_GppProcessCore.CoreFlowList[0].Level1List[0].Parameters[1] = "10";
            temp_GppProcessCore.CoreFlowList[0].Level1List[0].Parameters[2] = "20";
            temp_GppProcessCore.CoreFlowList[0].Level1List[0].Parameters[3] = "50";
            temp_GppProcessCore.CoreFlowList[0].Level1List[0].Parameters[4] = "40";

            //
            temp_GppProcessCore.CoreFlowList[0].Level1List[1] = new ClsLevel1();
            temp_GppProcessCore.CoreFlowList[0].Level1List[1].Type = "LIGHT";
            temp_GppProcessCore.CoreFlowList[0].Level1List[1].Action = "Initial";
            temp_GppProcessCore.CoreFlowList[0].Level1List[1].WaitTime = 1000;

            Array.Resize(ref temp_GppProcessCore.CoreFlowList[0].Level1List[1].Parameters, 3);
            temp_GppProcessCore.CoreFlowList[0].Level1List[1].Parameters[0] = "192.168.0.100";
            temp_GppProcessCore.CoreFlowList[0].Level1List[1].Parameters[1] = "10";
            temp_GppProcessCore.CoreFlowList[0].Level1List[1].Parameters[2] = "20";

            temp_GppProcessCore.WriteWithoutCrypto(filePath, true);

            //
            this.richTextBox1.Clear();
            this.richTextBox1.Text = System.IO.File.ReadAllText(filePath, Encoding.Default);

            Console.WriteLine("Genetare flowlist file");
        }

        private void btnTestFlow_Click(object sender, EventArgs e)
        {
            string fullPath = ".\\testXml001.xml";

            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = System.IO.Path.GetDirectoryName(fullPath);
                openFileDialog.Filter = "xml files (*.xml)|*.xml|All files (*.*)|*.*";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    //Get the path of specified file
                    fullPath = openFileDialog.FileName;
                }
                else
                {
                    Console.WriteLine("User cancel the option");
                    return;
                }
            }

            try
            {
                this.g_ProcessCore = new ProcessCore(fullPath);

                this.g_ProcessCore.Initial();

                this.g_ProcessCore.Start();

            }
            catch (Exception ex)
            {

            }

        }

        private void btnGenerate2_Click(object sender, EventArgs e)
        {

            string filePath = ".\\testXml002.xml";

            GppProcessCore temp_GppProcessCore = new GppProcessCore();

            // DeviceList




            // FlowList
            int i = 0;
            int j = 0;

            Array.Resize(ref temp_GppProcessCore.CoreFlowList, 1);
            temp_GppProcessCore.CoreFlowList[i] = new FlowList();
            temp_GppProcessCore.CoreFlowList[i].id = 0;
            temp_GppProcessCore.CoreFlowList[i].loopCnt = "ForEver";

            //
            Array.Resize(ref temp_GppProcessCore.CoreFlowList[i].Level1List, 5);

            //
            temp_GppProcessCore.CoreFlowList[i].Level1List[j] = new ClsLevel1();
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].Type = "LIGHT";
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].Action = "Initial";
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].WaitTime = 3000;

            Array.Resize(ref temp_GppProcessCore.CoreFlowList[i].Level1List[j].Parameters, 5);
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].Parameters[0] = "192.168.0.1";
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].Parameters[1] = "10";
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].Parameters[2] = "20";
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].Parameters[3] = "50";
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].Parameters[4] = "40";

            //
            j++;
            temp_GppProcessCore.CoreFlowList[i].Level1List[j] = new ClsLevel1();
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].Type = "LIGHT";
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].Action = "Open";
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].WaitTime = 0;

            Array.Resize(ref temp_GppProcessCore.CoreFlowList[i].Level1List[j].Parameters, 2);
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].Parameters[0] = "10";
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].Parameters[1] = "20";

            //
            j++;
            temp_GppProcessCore.CoreFlowList[i].Level1List[j] = new ClsLevel1();
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].Type = "LIGHT";
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].Action = "Close";
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].WaitTime = 0;

            //
            j++;
            temp_GppProcessCore.CoreFlowList[i].Level1List[j] = new ClsLevel1();
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].Type = "PLC";
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].Action = "Initial";
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].WaitTime = 2000;

            Array.Resize(ref temp_GppProcessCore.CoreFlowList[i].Level1List[j].Parameters, 8);
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].Parameters[0] = "192.168.0.1";
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].Parameters[1] = "10";
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].Parameters[2] = "20";
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].Parameters[3] = "50";
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].Parameters[4] = "40";
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].Parameters[5] = "30";
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].Parameters[6] = "20";
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].Parameters[7] = "10";

            //
            j++;
            temp_GppProcessCore.CoreFlowList[i].Level1List[j] = new ClsLevel1();
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].Type = "PLC";
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].Action = "Close";
            temp_GppProcessCore.CoreFlowList[i].Level1List[j].WaitTime = 0;


            temp_GppProcessCore.WriteWithoutCrypto(filePath, true);

            //
            this.richTextBox1.Clear();
            this.richTextBox1.Text = System.IO.File.ReadAllText(filePath, Encoding.Default);

            Console.WriteLine("Genetare flowlist file");


        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            if (this.g_ProcessCore == null)
            {
                Console.WriteLine("Please click testFlow first!");
                return;
            }

            this.g_ProcessCore.Stop();

        }

        private void btnPause_Click(object sender, EventArgs e)
        {
            if (this.g_ProcessCore == null)
            {
                Console.WriteLine("Please click testFlow first!");
                return;
            }

            this.g_ProcessCore.Pause();
        }

        private void btnRestore_Click(object sender, EventArgs e)
        {
            if (this.g_ProcessCore == null)
            {
                Console.WriteLine("Please click testFlow first!");
                return;
            }

            this.g_ProcessCore.Restore();
        }
    }
}
