﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrjTestGppFlow
{
    public class ClsPlc : IBaseObject
    {
        public string Initial()
        {
            Console.WriteLine("[ClsPlc Initial] : set plc parametets");
            return "ClsPlc Initial";
        }

        public string Open()
        {
            Console.WriteLine("[ClsPlc Open] : open plc");
            return "ClsPlc Open";
        }

        public string Close()
        {
            Console.WriteLine("[ClsPlc Close] : close plc");
            return "ClsPlc Close";
        }

        public void WriteDevice(string o_device, int o_value)
        {
            Console.WriteLine("[ClsPlc SetDevice] : write " + o_device + " to " + o_value);
        }

        public void ReadDevice(string o_device, ref int o_value)
        {
            Console.WriteLine("[ClsPlc ReadDevice] : read " + o_value + " from " + o_device);
        }
    }
}
