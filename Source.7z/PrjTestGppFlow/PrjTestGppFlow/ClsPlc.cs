﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrjTestGppFlow
{
    public class ClsPlc : BaseObject
    {
        public string Ip;
        
        public override void Initial()
        {
            Console.WriteLine("[ClsPlc Initial] : set plc parametets");
        }

        public override void Open()
        {
            Console.WriteLine("[ClsPlc Open] : open plc");
        }

        public override void Close()
        {
            Console.WriteLine("[ClsPlc Close] : close plc");
        }

        public void Run()
        {

        }

        public void WriteDevice(string o_device, int o_value)
        {
            Console.WriteLine("[ClsPlc SetDevice] : write " + o_device + " to " + o_value);
        }

        public void ReadDevice(string o_device, ref int o_value)
        {
            Console.WriteLine("[ClsPlc ReadDevice] : read " + o_value + " from " + o_device);
        }
    }
}
