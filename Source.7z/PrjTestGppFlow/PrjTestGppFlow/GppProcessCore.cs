﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Collections;

namespace PrjTestGppFlow
{
    public class ClsVariable
    {
        string Name = "P0";
        string Type = "string"; // string, int, double, bool
        object Value;
    }

    // each device action 
    public class ClsLevel1
    {
        public int WaitTime = 0;
        public int DelayTime = 0;

        public string ObjectName = "LV1"; // check the action Object
        public int ObjectId = 0;

        public string Type = ""; // PLC
        public string Action = ""; // Open

        public int DeviceId = 0;
        
        public string[] Parameters = new string[0];
    }

    // each thread flow
    public class FlowList
    {
        public int id; // threadID

        public string Name;
        public string loopCnt;

        public ClsLevel1[] Level1List;
        public ClsVariable[] VariableList;

        public FlowList()
        {
            this.id = 0;

            this.Name = "FlowList";

            this.loopCnt = "ForEver";

            this.Level1List = new ClsLevel1[0];
            this.VariableList = new ClsVariable[0];
        }
    }

    public class GppProcessCore : CommonBase.Config.BaseConfig<GppProcessCore>
    {
        private string classVersion = "GppProcessCore_20210614";

        public DeviceList[] CoreDeviceList;
        public VariableList[] CoreVariableList;
        public FlowList[] CoreFlowList;


        public GppProcessCore()
        {
            try
            {
                this.CoreDeviceList = new DeviceList[0];
                this.CoreFlowList = new FlowList[0];
            }
            catch (Exception ex)
            {

            }

        }

        protected override bool CheckValue(GppProcessCore tmpConfig)
        {

            if (tmpConfig.CoreDeviceList.Length > 0)
                Array.Resize(ref this.CoreDeviceList, tmpConfig.CoreDeviceList.Length);
            for (int cnt = 0; cnt < tmpConfig.CoreDeviceList.Length; cnt++)
            {
                if (this.CoreDeviceList[cnt] == null)
                    this.CoreDeviceList[cnt] = new DeviceList();

                this.CoreDeviceList[cnt] = tmpConfig.CoreDeviceList[cnt];
            }

            if (tmpConfig.CoreFlowList.Length > 0)
                Array.Resize(ref this.CoreFlowList, tmpConfig.CoreFlowList.Length);
            for (int cnt = 0; cnt < tmpConfig.CoreFlowList.Length; cnt++)
            {
                if (this.CoreFlowList[cnt] == null)
                    this.CoreFlowList[cnt] = new FlowList();

                this.CoreFlowList[cnt] = tmpConfig.CoreFlowList[cnt];
            }

            //	Read NAME
            this.Name = tmpConfig.Name;

            //	Read UPDATE
            this.Update = tmpConfig.Update;

            //	Read VERSION
            this.Version = this.classVersion;

            if (this.Version != tmpConfig.Version)
                return false;
            else
                return true;
        }
    }

    public class ProcessCore
    {
        private bool isRun;
        private bool isPause;

        public GppProcessCore CoreConfig;

        public ProcessCore(string o_Fullpath)
        {
            try
            {
                if (!System.IO.File.Exists(o_Fullpath))
                    throw new Exception(String.Format(
                        "File not exist. [{0}]", o_Fullpath));

                this.CoreConfig = new GppProcessCore();
                this.CoreConfig.ReadWithoutCrypto(o_Fullpath);

            }
            catch (Exception ex)
            {

            }

        }

        private void _thradToCheckFlow(Object o_Object)
        {

            FlowList temp_FlowList = (FlowList)o_Object;

            int temploopCnt = 999;

            Console.WriteLine("---------- Start the loop id : " + temp_FlowList.Name + " ----------");

            if (temp_FlowList.loopCnt != "ForEver")
            {
                temploopCnt = Convert.ToInt32(temp_FlowList.loopCnt);

                Console.WriteLine("Total Run : " + temploopCnt);
            }
            else
            {
                Console.WriteLine("Total Run : " + temp_FlowList.loopCnt);
            }

            while (this.isRun && temploopCnt > 0)
            {
                if (temp_FlowList.loopCnt != "ForEver")
                {
                    Console.WriteLine("Cnt : " + temploopCnt);
                }
                else
                {
                    Console.WriteLine("Cnt : " + temp_FlowList.loopCnt);
                }


                for (int i = 0; i < temp_FlowList.Level1List.Length; i++)
                {
 
                    // Check pause ?
                    bool nowPause = true;
                    while (this.isPause)
                    {
                        if (nowPause)
                        {
                            Console.WriteLine("Pause in Type : " + temp_FlowList.Level1List[i].Type + Environment.NewLine);
                            Console.WriteLine("Pause in Action : " + temp_FlowList.Level1List[i].Action + Environment.NewLine);
                            nowPause = false;
                        }
                        Thread.Sleep(10);
                    }

                    // delay to start the job
                    Thread.Sleep(temp_FlowList.Level1List[i].DelayTime);


                    // 
                    string msg = "";
                    msg += "Name : " + temp_FlowList.Level1List[i].ObjectName + Environment.NewLine;
                    msg += "Id : " + temp_FlowList.Level1List[i].ObjectId + Environment.NewLine;
                    msg += "Type : " + temp_FlowList.Level1List[i].Type + Environment.NewLine;
                    msg += "Action : " + temp_FlowList.Level1List[i].Action + Environment.NewLine;

                    msg += "Parameters : ";
                    for (int j = 0; j < temp_FlowList.Level1List[i].Parameters.Length; j++)
                    {
                        msg += temp_FlowList.Level1List[i].Parameters[j];

                        if (j != temp_FlowList.Level1List[i].Parameters.Length - 1)
                        {
                            msg += ", ";
                        }
                    }
                    msg += Environment.NewLine;
                    msg += "DelayTime : " + temp_FlowList.Level1List[i].DelayTime + Environment.NewLine;
                    msg += "WaitTime : " + temp_FlowList.Level1List[i].WaitTime;

                    if (i != temp_FlowList.Level1List.Length - 1)
                    {
                        msg += Environment.NewLine;
                    }

                    Console.WriteLine(msg);


                    // do the job 
                    // exercute (by dictionary ?)
                    

                    // wait to check the next job
                    Thread.Sleep(temp_FlowList.Level1List[i].WaitTime);



                }

                if (temp_FlowList.loopCnt != "ForEver")
                {
                    temploopCnt--;
                }
                Thread.Sleep(10);
            }

            Console.WriteLine("---------- Exit the loop : " + temp_FlowList.id + " ----------");
        }

        public void Initial()
        {
            // check all object device
            Console.WriteLine("----> ProcessCore Initial <----");


        }

        public void Start()
        {
            Console.WriteLine("----> ProcessCore Start <----");

            //
            int threadCnt = this.CoreConfig.CoreFlowList.Length;

            this.isRun = true;
            //
            for (int i = 0; i < threadCnt; i++)
            {
                //
                Thread checkTask = new Thread(new ParameterizedThreadStart(_thradToCheckFlow));
                checkTask.Name = "checkTask";
                checkTask.Start(this.CoreConfig.CoreFlowList[i]);
            }
        }

        public void Pause()
        {
            Console.WriteLine("----> ProcessCore Pause <----");

            this.isPause = true;
        }

        public void Restore()
        {
            Console.WriteLine("----> ProcessCore Restore <----");

            this.isPause = false;
        }

        public void Stop()
        {
            Console.WriteLine("----> ProcessCore Stop <----");

            this.isRun = false;
        }





    }
    



}
