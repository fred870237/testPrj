﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrjTestGppFlow
{
    public interface IBaseObject
    {
        string Initial();

        string Open();

        string Close();
    }


    public class DeviceList
    {
        public IBaseObject m_IBaseObject;

        public DeviceList()
        {
            
        }

        public void Initial()
        {


        }


    }
}
