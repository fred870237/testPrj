﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrjTestGppFlow
{
    public class BaseObject
    {
        public string ObjectName;
        public int ObjectId;

        public virtual void Initial()
        {
            
        }

        public virtual void Open()
        {

        }

        public virtual void Close()
        {

        }
    }


    public class DeviceList
    {
        public BaseObject m_BaseObject;

        public DeviceList()
        {
            
        }

        public void Initial()
        {


        }


    }
}
