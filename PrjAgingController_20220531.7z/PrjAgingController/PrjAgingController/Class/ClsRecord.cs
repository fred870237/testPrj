﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace PrjAgingController.Class
{
    // Image group
    public class _st_ImageGroup_
    {
        public int Index;
        public bool eachJudgeResult;
        public List<string> ml_imagePath;

        public _st_ImageGroup_()
        {

        }
    }

    // Camera group
    public class _st_CameraGroup_
    {
        public string Id;
        public int SiteIndex;
        public bool JudgeResult;

        public int ImageCnt;
        public List<_st_ImageGroup_> ml_st_ImageGroup_;

        public _st_CameraGroup_()
        {

        }
    }


    // Daily
    public class ClsRecordControl
    {
        private CommonBase.Logger.InfoManager m_InfoManager = null;

        private string m_CurrentDate;

        private int TotalCnt;
        private int OkCnt;
        private int NgCnt;
        private float OkRatio;
        private float NgRatio;

        public List<_st_CameraGroup_> ml_st_CameraGroup_;

        public ClsRecordControl()
        {



        }

        public ClsRecordControl(
            string o_nowDate,
            CommonBase.Logger.InfoManager o_InfoManager)
        {



        }

        private	void _resetToInitial(string o_CurrentDate)
        {
            this.m_CurrentDate = o_CurrentDate;

            this.TotalCnt = 0;

            //
            this.OkCnt = 0;
            this.NgCnt = 0;
            this.OkRatio = 0;
            this.NgRatio = 0;

            this.ml_st_CameraGroup_.Clear();
        }

        public void CheckCurrentDate(string o_CurrentDate)
        {
            // 
            if (this.m_CurrentDate != o_CurrentDate)
            {
                this._resetToInitial(o_CurrentDate);
            }
        }

        public bool RecordAddOneResult(_st_CameraGroup_ o_st_CameraGroup_, string o_CurrentDate)
        {
            if (o_st_CameraGroup_ == null)
            {
                return false;
            }

            // 
            if (this.m_CurrentDate != o_CurrentDate)
            {
                this._resetToInitial(o_CurrentDate);
            }

            this.TotalCnt++;

            if (o_st_CameraGroup_.JudgeResult) 
            {
                this.OkCnt++; 
            }
            else 
            {
                this.NgCnt++;
            }
            this.OkRatio = (float)this.OkCnt / (float)this.TotalCnt;
            this.NgRatio = (float)this.NgCnt / (float)this.TotalCnt;

            this.ml_st_CameraGroup_.Add(o_st_CameraGroup_);

            return true;
        }

        public static ClsRecordControl ReadXML(string fileName)
        {
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(ClsRecordControl));
                StreamReader sr = new StreamReader(fileName, System.Text.Encoding.Default);
                ClsRecordControl m_Object = (ClsRecordControl)(serializer.Deserialize(sr));
                sr.Close();
                return m_Object;
            }
            catch (Exception ex)
            {
                throw new Exception("[ClsRecordControl.ReadXML] Read ClsRecordControl XML Error !(" + ex.Message + ")(" + ex.StackTrace + ")");
            }
        }

        public static void WriteXML(ClsRecordControl p_Object, string fileName)
        {
            try
            {
                if (!System.IO.Directory.Exists(System.IO.Path.GetDirectoryName(fileName)))
                {
                    System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(fileName));
                }

                XmlSerializer serializer = new XmlSerializer(typeof(ClsRecordControl));
                StreamWriter sw = new StreamWriter(fileName, false, System.Text.Encoding.Unicode);
                serializer.Serialize(sw, p_Object);
                sw.Close();
            }
            catch (Exception ex)
            {
                throw new Exception("[ClsRecordControl.WriteXML] Write ClsRecordControl XML Error !(" + ex.Message + ")(" + ex.StackTrace + ")");
            }
        }



    }




}
