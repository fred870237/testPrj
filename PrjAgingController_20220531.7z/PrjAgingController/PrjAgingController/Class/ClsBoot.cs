﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrjAgingController.Class
{
    public static class Common
    {
        public static string AGING_NAME = "Aging_Controller";
        public static string AGING_VERSION = "V001";
        public static string AGING_REVERSION = "22.0513.1116";
        public static string AGING_CONTROLLER_APP_VERSION =
            (AGING_NAME + "_" + AGING_VERSION + "_" + AGING_REVERSION);

        public static string CONFIG_FOLDER = System.Windows.Forms.Application.StartupPath + "\\CtrlConfig\\";
        public static string DEFAULT_CONFIG_FOLDER = System.Windows.Forms.Application.StartupPath + "\\DefaultCtrlConfig\\";

        public static string BOOT_CONFIG_NAME = "BootConfig.xml";
        public static string NETWORK_CONFIG_NAME = "NetworkConfig.xml";
        //public static string PLC_CONFIG_NAME = "PlcConfig.xml";
        public static string RECORD_CONFIG_NAME = "RecordConfig.xml";

        public static string RECORD_RESULT_NAME = "RecordResult.xml";
    }

    public partial class ClsBootConfig : CommonBase.Config.BaseConfig<ClsBootConfig>
    {
        private string classVersion = "ClsBootConfig_202205131119";

        public string rootPath;

        public ClsBootConfig()
        {
            this.rootPath = "D:\\Aging";
        }
        protected override bool CheckValue(ClsBootConfig tmpConfig)
        {
            this.rootPath = tmpConfig.rootPath;

            //	Read UPDATE
            this.Update = tmpConfig.Update;

            //	Read VERSION
            this.Version = this.classVersion;

            if (this.Version != tmpConfig.Version)
                return false;
            else
                return true;
        }
    }

}
