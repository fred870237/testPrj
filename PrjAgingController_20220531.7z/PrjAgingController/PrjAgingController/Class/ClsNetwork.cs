﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Drawing.Design;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using System.IO;
using System.Drawing;

namespace PrjAgingController.Class
{

    public class _st_NetworkGroup_
    {
        [DisplayName("0.1 ID"), Description("ID")]
        public string ID { get; set; }

        [DisplayName("0.2 Enable"), Description("Enable")]
        public bool Enable { get; set; }

        [DisplayName("0.3 ServerIp"), Description("ServerIp")]
        public string ServerIp { get; set; }

        [DisplayName("0.4 ServerPort"), Description("ServerPort")]
        public int ServerPort { get; set; }

        [DisplayName("0.5 ClientIp"), Description("ClientIp")]
        public string ClientIp { get; set; }

        [DisplayName("0.6 ClientPort"), Description("ClientPort")]
        public int ClientPort { get; set; }

        [DisplayName("0.7 CaptureFrameNumber"), Description("CaptureFrameNumber")]
        public int CaptureFrameNumber { get; set; }

        [DisplayName("0.8 ReceiveDataReverse"), Description("ReceiveDataReverse")]
        public bool ReceiveDataReverse { get; set; }

        public _st_NetworkGroup_()
        {
            this.ID = "NetGroup";

            this.Enable = true;

            this.ServerIp = "127.0.0.1";
            this.ServerPort = 9000;

            this.ClientIp = "127.0.0.1";
            this.ClientPort = 9001;

            this.CaptureFrameNumber = 10;

            this.ReceiveDataReverse = true;
        }
    }

    public partial class ClsNetworkConfig : CommonBase.Config.BaseConfig<ClsNetworkConfig>
    {
        private string classVersion = "ClsNetworkConfig_202205161327";

        [DisplayName("Network Group"), Description("The setting of network : pc - mobile")]
        [Editor(typeof(TestEditor), typeof(UITypeEditor))]
        public List<_st_NetworkGroup_> ml_st_NetworkGroup_ { get; set; }

        public int m_ClientWidth;
        public int m_ClientHeight;

        public ClsNetworkConfig()
        {
            this.ml_st_NetworkGroup_ = new List<_st_NetworkGroup_> { };

            this.m_ClientWidth = 100;
            this.m_ClientHeight = 100;
        }

        public class TestEditor : CollectionEditor
        {
            public TestEditor(Type type)
                : base(type)
            {
            }

            protected override string GetDisplayText(object value)
            {
                if (value is _st_NetworkGroup_)
                {
                    return ((_st_NetworkGroup_)value).ID;
                }
                else
                {
                    return value.ToString();
                }
            }
        }

        public void UpdateParams(ClsNetworkConfig o_ClsNetworkConfig)
        {
            this.ml_st_NetworkGroup_ = o_ClsNetworkConfig.ml_st_NetworkGroup_;

            this.m_ClientWidth = o_ClsNetworkConfig.m_ClientWidth;

            this.m_ClientHeight = o_ClsNetworkConfig.m_ClientHeight;
        }

        protected override bool CheckValue(ClsNetworkConfig tmpConfig)
        {
            this.ml_st_NetworkGroup_ = tmpConfig.ml_st_NetworkGroup_;

            this.m_ClientWidth = tmpConfig.m_ClientWidth;
            this.m_ClientHeight = tmpConfig.m_ClientHeight;

            //	Read UPDATE
            this.Update = tmpConfig.Update;

            //	Read VERSION
            this.Version = this.classVersion;

            if (this.Version != tmpConfig.Version)
                return false;
            else
                return true;
        }
    }

    public class _st_HandleImageSeries_
    {
        public int Index;
        public int NeedCaptureCnt;
        public List<MemoryStream> ml_MemoryStream;

        public _st_HandleImageSeries_(
            int o_Index, int o_NeedCaptureCnt)
        {
            this.Index = o_Index;
            this.NeedCaptureCnt = o_NeedCaptureCnt;
            this.ml_MemoryStream = new List<MemoryStream> { };
        }
    }

    public class _st_ServerDataGroup_
    {
        public int m_Index;
        public string m_ServerIp;
        public int m_ServerPort;
        public bool m_DataReverse;

        public _st_ServerDataGroup_(
            int o_Index,
            string o_ServerIp,
            int o_ServerPort,
            bool o_DataReverse)
        {
            this.m_Index = o_Index;
            this.m_ServerIp = o_ServerIp;
            this.m_ServerPort = o_ServerPort;
            this.m_DataReverse = o_DataReverse;
        }
    }

    public class _st_ClientDataGroup_
    {
        public int m_Index;
        public string m_ClientIp;
        public int m_ClientPort;
        public int m_CapFrameNumber;

        public _st_ClientDataGroup_(
            int o_Index,
            string o_ClientIp,
            int o_ClientPort,
            int o_CapFrameNumber)
        {
            this.m_Index = o_Index;
            this.m_ClientIp = o_ClientIp;
            this.m_ClientPort = o_ClientPort;
            this.m_CapFrameNumber = o_CapFrameNumber;
        }
    }

    public class ClsNetworkControl
    {
        private ClsNetworkConfig m_ClsNetworkConfig = null;

        private CommonBase.Logger.InfoManager m_InfoManager = null;

        private bool isStartOn = false;

        private List<Socket> ml_SocketServer = null;
        private List<_st_HandleImageSeries_> ml_st_HandleImageSeries_ = null;

        public ClsNetworkControl(
            ClsNetworkConfig o_ClsNetworkConfig,
            CommonBase.Logger.InfoManager o_InfoManager)
        {
            this.m_ClsNetworkConfig = o_ClsNetworkConfig;
            this.m_InfoManager = o_InfoManager;
        }

        private void _handleImageGroup(int o_Index, MemoryStream o_ms)
        {
            Monitor.Enter(this);
            try
            {
                //
                string saveFolder = $"{this.m_ClsBootConfig.rootPath}\\Output\\" +
                    $"{this.m_StartApplicationDay.ToString("yyyyMMdd")}\\{this.m_currentId}\\{o_Index}";

                if (!System.IO.Directory.Exists(saveFolder))
                {
                    System.IO.Directory.CreateDirectory(saveFolder);
                }
                string savePath = saveFolder + "\\" + DateTime.Now.ToString("HHmmss") + "_img.jpeg";

                MemoryStream ms = new MemoryStream();

                o_ms.Seek(0, System.IO.SeekOrigin.Begin);
                o_ms.CopyTo(ms);

                this.ml_st_HandleImageSeries_[o_Index].ml_MemoryStream.Add(ms);
                this.m_InfoManager.General($"Add {o_Index}");

                bool isAllReceiveDone = true;
                for (int i = 0; i < this.ml_st_HandleImageSeries_.Count; i++)
                {
                    if (this.ml_st_HandleImageSeries_[i].NeedCaptureCnt !=
                        this.ml_st_HandleImageSeries_[i].ml_MemoryStream.Count)
                    {
                        isAllReceiveDone = false;
                    }
                }

                if (isAllReceiveDone)
                {
                    this.m_InfoManager.General("HandleImageGroup all receive done");
                }
                //Image img = Image.FromStream(ms);
                //img.Save(savePath, ImageFormat.Jpeg);

                //this.m_InfoManager.General("HandleImageGroup : " + savePath + " OK!");
            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error($"[HandleImageGroup] index:{o_Index} error, " + ex.Message);
            }
            finally
            {
                Monitor.Exit(this);
            }
        }

        // server
        private void _threadToReceiveImage_(object o_object)
        {
            int tmpIndex = 0;
            string tmpIp = "";
            int tmpPort = 0;
            try
            {
                _st_ServerDataGroup_ tmp_st_ServerDataGroup_ = (_st_ServerDataGroup_)o_object;
                tmpIndex = tmp_st_ServerDataGroup_.m_Index;
                tmpIp = tmp_st_ServerDataGroup_.m_ServerIp;
                tmpPort = tmp_st_ServerDataGroup_.m_ServerPort;
                bool tmpDataReverse = tmp_st_ServerDataGroup_.m_DataReverse;

                //
                Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                this.ml_SocketServer.Add(socket);

                IPEndPoint ipep = new IPEndPoint(IPAddress.Parse(tmpIp), tmpPort);
                socket.Bind(ipep);
                socket.Listen(2);

                this.m_InfoManager.General(string.Format("Index:{0} Enter", tmpIndex));
                while (true)
                {
                    try
                    {
                        if (!this.isStartOn)
                        {
                            //this.m_InfoManager.General(string.Format("Index:{0} Exit", tmpIndex));
                            break;
                        }

                        byte[] data = new byte[8];
                        Socket clientSocket = socket.Accept();
                        if (clientSocket.Connected)
                        {
                            clientSocket.Receive(data, data.Length, SocketFlags.None);

                            if (tmpDataReverse)
                            {
                                Array.Reverse(data);
                            }
                            long contentLength = BitConverter.ToInt64(data, 0);

                            int size = 0;
                            MemoryStream ms = new MemoryStream();
                            while (size < contentLength)
                            {
                                byte[] bits = new byte[2048];
                                int r = clientSocket.Receive(bits, bits.Length, SocketFlags.None);
                                if (r <= 0) break;
                                ms.Write(bits, 0, r);
                                size += r;
                            }
                            //Image img = Image.FromStream(ms);
                            //this.m_HandleImageGroupCallback(tmpIndex, ms);

                            this.m_InfoManager.HighLight($"{tmpIndex} Receive image, size:{size}");

                            clientSocket.Close();

                            ms.Flush();
                            ms.Close();
                            ms.Dispose();
                        }

                        Thread.Sleep(10);
                    }
                    catch (Exception ex)
                    {
                        // when call socket close, it would occur this exception, but it is all right
                       
                        //this.m_InfoManager.Error("[_threadToReceiveImage_] receive error, " + ex.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                string errMsg = string.Format("[_threadToReceiveImage_] thread error, index:[{0}], ip:[{1}], port[{2}] ",
                    tmpIndex, tmpIp, tmpPort);

                this.m_InfoManager.Error(errMsg + ex.Message);
            }
            finally
            {
                this.m_InfoManager.General(string.Format("Index:{0} Exit", tmpIndex));
            }
        }

        public void StartServer()
        {
            try
            {
                this.isStartOn = true;

                this.ml_SocketServer = new List<Socket> { };
                this.ml_st_HandleImageSeries_ = new List<_st_HandleImageSeries_> { };

                for (int i = 0; i < this.m_ClsNetworkConfig.ml_st_NetworkGroup_.Count; i++)
                {
                    _st_ServerDataGroup_ tmp_st_ServerDataGroup_ = new _st_ServerDataGroup_(
                        i,
                        this.m_ClsNetworkConfig.ml_st_NetworkGroup_[i].ServerIp,
                        this.m_ClsNetworkConfig.ml_st_NetworkGroup_[i].ServerPort,
                        this.m_ClsNetworkConfig.ml_st_NetworkGroup_[i].ReceiveDataReverse);

                    // thread
                    if (this.m_ClsNetworkConfig.ml_st_NetworkGroup_[i].Enable)
                    {
                        Thread tmpThread = new Thread(new ParameterizedThreadStart(_threadToReceiveImage_));
                        tmpThread.Name = "tReceiveImage_" + i;
                        tmpThread.Start(tmp_st_ServerDataGroup_);

                        this.m_InfoManager.General(string.Format("[StartServer] Index:[{0}] Enable", i));
                    }
                    else
                    {
                        this.m_InfoManager.General(string.Format("[StartServer] Index:[{0}] Disable", i));
                    }
                }

            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error("[StartServer] error, " + ex.Message);
            }
        }

        public void StopServer()
        {
            try
            {
                this.isStartOn = false;

                for (int i = 0; i < this.ml_SocketServer.Count; i++)
                {
                    this.ml_SocketServer[i].Close();
                }
            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error("[StopServer] error, " + ex.Message);
            }

        }

        // client
        private void _threadToSendTrigger_(object o_object)
        {
            try
            {
                _st_ClientDataGroup_ tmp_st_ClientDataGroup_ = (_st_ClientDataGroup_)o_object;
                int tmpIndex = tmp_st_ClientDataGroup_.m_Index;
                string tmpIp = tmp_st_ClientDataGroup_.m_ClientIp;
                int tmpPort = tmp_st_ClientDataGroup_.m_ClientPort;
                int tmpCapFrameNumber = tmp_st_ClientDataGroup_.m_CapFrameNumber;

                //例項化socket               
                Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                IPEndPoint ipep = new IPEndPoint(IPAddress.Parse(tmpIp), tmpPort);
                socket.Connect(ipep);

                string value = "Trigger_" + tmpCapFrameNumber;
                byte[] bytes = System.Text.Encoding.UTF8.GetBytes(value);

                socket.Send(bytes);

                socket.Close();
            }
            catch (Exception ex)
            {

            }

        }

        public void SendTrigger()
        {
            try
            {
                for (int i = 0; i < this.m_ClsNetworkConfig.ml_st_NetworkGroup_.Count; i++)
                {
                    _st_ClientDataGroup_ tmp_st_ClientDataGroup_ = new _st_ClientDataGroup_(
                        i,
                        this.m_ClsNetworkConfig.ml_st_NetworkGroup_[i].ClientIp,
                        this.m_ClsNetworkConfig.ml_st_NetworkGroup_[i].ClientPort,
                        this.m_ClsNetworkConfig.ml_st_NetworkGroup_[i].CaptureFrameNumber);

                    // thread
                    if (this.m_ClsNetworkConfig.ml_st_NetworkGroup_[i].Enable)
                    {
                        Thread tmpThread = new Thread(new ParameterizedThreadStart(_threadToSendTrigger_));
                        tmpThread.Name = "tSendTrigger_" + i;
                        tmpThread.Start(tmp_st_ClientDataGroup_);
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        // send image test
        private void _threadToSendImage_(object o_object)
        {
            int tmpIndex = 0;
            string tmpIp = "";
            int tmpPort = 0;
            try
            {
                _st_ServerDataGroup_ tmp_st_ServerDataGroup_ = (_st_ServerDataGroup_)o_object;
                tmpIndex = tmp_st_ServerDataGroup_.m_Index;
                tmpIp = tmp_st_ServerDataGroup_.m_ServerIp;
                tmpPort = tmp_st_ServerDataGroup_.m_ServerPort;
                bool tmpDataReverse = tmp_st_ServerDataGroup_.m_DataReverse;

                //例項化socket               
                Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                IPEndPoint ipep = new IPEndPoint(IPAddress.Parse(tmpIp), tmpPort);
                socket.Connect(ipep);

                FileStream fs;

                if (tmpIndex == 0) {
                    fs = new FileStream(@"C:\Users\fredchiang\Desktop\B156XTN08_V1\QQQQQ.bmp", FileMode.Open);
                }
                else
                {
                    fs = new FileStream(@"C:\Users\fredchiang\Desktop\B156XTN08_V1\99999.bmp", FileMode.Open);
                }

                long contentLength = fs.Length;
                //第一次傳送資料包的大小           
                socket.Send(BitConverter.GetBytes(contentLength));

                while (true)
                {
                    //每次傳送128位元組               
                    byte[] bits = new byte[4096];
                    int r = fs.Read(bits, 0, bits.Length);
                    if (r <= 0) break;
                    socket.Send(bits, r, SocketFlags.None);
                }
                socket.Close();
                fs.Position = 0;

                fs.Close();
            }
            catch (Exception ex)
            {

            }
        }

        public void SendImage()
        {
            try
            {
                for (int i = 0; i < this.m_ClsNetworkConfig.ml_st_NetworkGroup_.Count; i++)
                {
                    _st_ServerDataGroup_ tmp_st_ServerDataGroup_ = new _st_ServerDataGroup_(
                        i,
                        this.m_ClsNetworkConfig.ml_st_NetworkGroup_[i].ServerIp,
                        this.m_ClsNetworkConfig.ml_st_NetworkGroup_[i].ServerPort,
                        this.m_ClsNetworkConfig.ml_st_NetworkGroup_[i].ReceiveDataReverse);

                    // thread
                    if (this.m_ClsNetworkConfig.ml_st_NetworkGroup_[i].Enable)
                    {
                        Thread tmpThread = new Thread(new ParameterizedThreadStart(_threadToSendImage_));
                        tmpThread.Name = "tSendImage_" + i;
                        tmpThread.Start(tmp_st_ServerDataGroup_);
                    }
                }
            }
            catch (Exception ex)
            {

            }

        }



    }


}
