﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace UR_Robot
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        ClsKernel clsKernel = new ClsKernel();
        private void btn_connect_Click(object sender, EventArgs e)
        {
            if (clsKernel.Connect30003(txb_ip.Text) & clsKernel.Connect29999(txb_ip.Text))
            {
                btn_connect.BackColor = Color.Lime;
            }
        }

        private void Btn_pwOn_Click(object sender, EventArgs e)
        {
            clsKernel.PowerOn();
        }

        private void Btn_pwOff_Click(object sender, EventArgs e)
        {
            clsKernel.PowerOff();
        }

        private void Btn_bkRelease_Click(object sender, EventArgs e)
        {
            clsKernel.BrakeRelease();
        }

        private void Btn_disconnect_Click(object sender, EventArgs e)
        {
            clsKernel.Disconnect();
        }

        private void Btn_move_Click(object sender, EventArgs e)
        {
            clsKernel.Move(txb_moveInstruct.Text);
        }

        private void Btn_stop_Click(object sender, EventArgs e)
        {
            clsKernel.Stop();
        }

        private void Btn_readRoute_Click(object sender, EventArgs e)
        {
            clsKernel.ReadRoute();
        }

        private void Btn_runRoute_Click(object sender, EventArgs e)
        {
            if(clsKernel._routeRunning == false)
            {
                clsKernel.Run();
            }
        }

        string line;
        string[] route;
        double x, y, z;

        private void Btn_home_Click(object sender, EventArgs e)
        {
            clsKernel.Move("movel(p[0.0943, -0.542, -0.326, 3.145, -0.023, 0.0116],a=0.3, v=0.1, t=0, r=0)");
        }

        private void Btn_revise_Click(object sender, EventArgs e)
        {
            OpenFileDialog opf = new OpenFileDialog();
            if(opf.ShowDialog() == DialogResult.OK)
            {
                StreamWriter sw = new StreamWriter(Application.StartupPath + "\\flower.txt");
            
                using (StreamReader sr = new StreamReader(opf.FileName))
                {
                    while((line = sr.ReadLine()) != null)
                    {
                        route = line.Split(',');
                        //x = Convert.ToDouble(route[0]) + (-47);
                        //y = Convert.ToDouble(route[1]) + (-745.7);
                        //z = Convert.ToDouble(route[2]) + (-100.0);
                        x = Convert.ToDouble(route[0]);
                        y = Convert.ToDouble(route[1]);
                        z = Convert.ToDouble(route[2]);
                        sw.WriteLine(x.ToString("#0.000") + "," + y.ToString("#0.000") + "," + z.ToString("#0.000") + ","
                             + route[3] + "," + route[4] + "," + route[5]);
                        //                  sw.WriteLine(x.ToString("#0.000") + "," + y.ToString("#0.000") + "," + z.ToString("#0.000") + ","
                        //+ "3.14," + "0.0,0.0");
                    }
                }
                sw.Close();
            }
            
        }
    }
}
