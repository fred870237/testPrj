﻿
namespace UR_Robot
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.txb_ip = new System.Windows.Forms.TextBox();
            this.btn_connect = new System.Windows.Forms.Button();
            this.btn_pwOn = new System.Windows.Forms.Button();
            this.btn_pwOff = new System.Windows.Forms.Button();
            this.btn_bkRelease = new System.Windows.Forms.Button();
            this.btn_disconnect = new System.Windows.Forms.Button();
            this.btn_move = new System.Windows.Forms.Button();
            this.btn_stop = new System.Windows.Forms.Button();
            this.txb_moveInstruct = new System.Windows.Forms.TextBox();
            this.btn_readRoute = new System.Windows.Forms.Button();
            this.btn_runRoute = new System.Windows.Forms.Button();
            this.btn_revise = new System.Windows.Forms.Button();
            this.btn_home = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txb_ip
            // 
            this.txb_ip.Location = new System.Drawing.Point(12, 12);
            this.txb_ip.Name = "txb_ip";
            this.txb_ip.Size = new System.Drawing.Size(101, 22);
            this.txb_ip.TabIndex = 0;
            this.txb_ip.Text = "192.168.1.2";
            // 
            // btn_connect
            // 
            this.btn_connect.Location = new System.Drawing.Point(119, 9);
            this.btn_connect.Name = "btn_connect";
            this.btn_connect.Size = new System.Drawing.Size(74, 28);
            this.btn_connect.TabIndex = 1;
            this.btn_connect.Text = "Connect";
            this.btn_connect.UseVisualStyleBackColor = true;
            this.btn_connect.Click += new System.EventHandler(this.btn_connect_Click);
            // 
            // btn_pwOn
            // 
            this.btn_pwOn.Location = new System.Drawing.Point(12, 40);
            this.btn_pwOn.Name = "btn_pwOn";
            this.btn_pwOn.Size = new System.Drawing.Size(74, 28);
            this.btn_pwOn.TabIndex = 2;
            this.btn_pwOn.Text = "Power On";
            this.btn_pwOn.UseVisualStyleBackColor = true;
            this.btn_pwOn.Click += new System.EventHandler(this.Btn_pwOn_Click);
            // 
            // btn_pwOff
            // 
            this.btn_pwOff.Location = new System.Drawing.Point(12, 74);
            this.btn_pwOff.Name = "btn_pwOff";
            this.btn_pwOff.Size = new System.Drawing.Size(74, 28);
            this.btn_pwOff.TabIndex = 3;
            this.btn_pwOff.Text = "Power Off";
            this.btn_pwOff.UseVisualStyleBackColor = true;
            this.btn_pwOff.Click += new System.EventHandler(this.Btn_pwOff_Click);
            // 
            // btn_bkRelease
            // 
            this.btn_bkRelease.Location = new System.Drawing.Point(92, 74);
            this.btn_bkRelease.Name = "btn_bkRelease";
            this.btn_bkRelease.Size = new System.Drawing.Size(101, 28);
            this.btn_bkRelease.TabIndex = 4;
            this.btn_bkRelease.Text = "Brake Release";
            this.btn_bkRelease.UseVisualStyleBackColor = true;
            this.btn_bkRelease.Click += new System.EventHandler(this.Btn_bkRelease_Click);
            // 
            // btn_disconnect
            // 
            this.btn_disconnect.Location = new System.Drawing.Point(119, 40);
            this.btn_disconnect.Name = "btn_disconnect";
            this.btn_disconnect.Size = new System.Drawing.Size(74, 28);
            this.btn_disconnect.TabIndex = 5;
            this.btn_disconnect.Text = "Disconncet";
            this.btn_disconnect.UseVisualStyleBackColor = true;
            this.btn_disconnect.Click += new System.EventHandler(this.Btn_disconnect_Click);
            // 
            // btn_move
            // 
            this.btn_move.Location = new System.Drawing.Point(12, 124);
            this.btn_move.Name = "btn_move";
            this.btn_move.Size = new System.Drawing.Size(74, 28);
            this.btn_move.TabIndex = 6;
            this.btn_move.Text = "Move";
            this.btn_move.UseVisualStyleBackColor = true;
            this.btn_move.Click += new System.EventHandler(this.Btn_move_Click);
            // 
            // btn_stop
            // 
            this.btn_stop.Location = new System.Drawing.Point(12, 158);
            this.btn_stop.Name = "btn_stop";
            this.btn_stop.Size = new System.Drawing.Size(74, 28);
            this.btn_stop.TabIndex = 7;
            this.btn_stop.Text = "Stop";
            this.btn_stop.UseVisualStyleBackColor = true;
            this.btn_stop.Click += new System.EventHandler(this.Btn_stop_Click);
            // 
            // txb_moveInstruct
            // 
            this.txb_moveInstruct.Location = new System.Drawing.Point(92, 127);
            this.txb_moveInstruct.Name = "txb_moveInstruct";
            this.txb_moveInstruct.Size = new System.Drawing.Size(415, 22);
            this.txb_moveInstruct.TabIndex = 8;
            this.txb_moveInstruct.Text = "movel(p[0.1126, -0.4308, 0.1695, 3.145, -0.023, 0.0116],a=0.3, v=0.1, t=0, r=0)";
            // 
            // btn_readRoute
            // 
            this.btn_readRoute.Location = new System.Drawing.Point(12, 211);
            this.btn_readRoute.Name = "btn_readRoute";
            this.btn_readRoute.Size = new System.Drawing.Size(74, 28);
            this.btn_readRoute.TabIndex = 9;
            this.btn_readRoute.Text = "Read Route";
            this.btn_readRoute.UseVisualStyleBackColor = true;
            this.btn_readRoute.Click += new System.EventHandler(this.Btn_readRoute_Click);
            // 
            // btn_runRoute
            // 
            this.btn_runRoute.Location = new System.Drawing.Point(92, 211);
            this.btn_runRoute.Name = "btn_runRoute";
            this.btn_runRoute.Size = new System.Drawing.Size(74, 28);
            this.btn_runRoute.TabIndex = 10;
            this.btn_runRoute.Text = "Run Route";
            this.btn_runRoute.UseVisualStyleBackColor = true;
            this.btn_runRoute.Click += new System.EventHandler(this.Btn_runRoute_Click);
            // 
            // btn_revise
            // 
            this.btn_revise.Location = new System.Drawing.Point(12, 264);
            this.btn_revise.Name = "btn_revise";
            this.btn_revise.Size = new System.Drawing.Size(74, 28);
            this.btn_revise.TabIndex = 12;
            this.btn_revise.Text = "Revise";
            this.btn_revise.UseVisualStyleBackColor = true;
            this.btn_revise.Click += new System.EventHandler(this.Btn_revise_Click);
            // 
            // btn_home
            // 
            this.btn_home.Location = new System.Drawing.Point(92, 155);
            this.btn_home.Name = "btn_home";
            this.btn_home.Size = new System.Drawing.Size(74, 28);
            this.btn_home.TabIndex = 13;
            this.btn_home.Text = "Home";
            this.btn_home.UseVisualStyleBackColor = true;
            this.btn_home.Click += new System.EventHandler(this.Btn_home_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_home);
            this.Controls.Add(this.btn_revise);
            this.Controls.Add(this.btn_runRoute);
            this.Controls.Add(this.btn_readRoute);
            this.Controls.Add(this.txb_moveInstruct);
            this.Controls.Add(this.btn_stop);
            this.Controls.Add(this.btn_move);
            this.Controls.Add(this.btn_disconnect);
            this.Controls.Add(this.btn_bkRelease);
            this.Controls.Add(this.btn_pwOff);
            this.Controls.Add(this.btn_pwOn);
            this.Controls.Add(this.btn_connect);
            this.Controls.Add(this.txb_ip);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txb_ip;
        private System.Windows.Forms.Button btn_connect;
        private System.Windows.Forms.Button btn_pwOn;
        private System.Windows.Forms.Button btn_pwOff;
        private System.Windows.Forms.Button btn_bkRelease;
        private System.Windows.Forms.Button btn_disconnect;
        private System.Windows.Forms.Button btn_move;
        private System.Windows.Forms.Button btn_stop;
        private System.Windows.Forms.TextBox txb_moveInstruct;
        private System.Windows.Forms.Button btn_readRoute;
        private System.Windows.Forms.Button btn_runRoute;
        private System.Windows.Forms.Button btn_revise;
        private System.Windows.Forms.Button btn_home;
    }
}

