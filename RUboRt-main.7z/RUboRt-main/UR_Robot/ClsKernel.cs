﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;

using System.Windows.Forms;
using System.IO;
using System.Threading;


public class ClsKernel
{
    #region
    Socket _socket29999, _socket30003;
    byte[] _DataByte29999 = new byte[1024];
    byte[] _DataByte30003 = new byte[2048];
    ASCIIEncoding _ascii = new ASCIIEncoding();
    List<string> _Route = new List<string>();
    double[] _PosAngle = new double[6];
    public bool _routeRunning = false;

    Task _getpos;
    bool _getActPos = false;
    #endregion

    public ClsKernel()
    {
    }
    private void mainProcess()
    {

    }

    public bool Connect29999(string IPAddr)
    {
        bool isConnect = false;

        try
        {
            if (_socket29999 == null)
            {
                _socket29999 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                _socket29999.Connect(IPAddr, 29999);
            }


            if (_socket29999.Connected)
            {
                Console.WriteLine("29999 Success");
                _socket29999.Send(Encoding.Default.GetBytes("PolyscopeVersion".ToCharArray()));
                _socket29999.Send(Encoding.Default.GetBytes("\n".ToCharArray()));
                _socket29999.Receive(_DataByte29999);
                Console.WriteLine(Analysis(_DataByte29999));
                _socket29999.Receive(_DataByte29999);
                Console.WriteLine(Analysis(_DataByte29999));
                isConnect = true;
            }

        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.ToString());
            isConnect = false;
        }

        return isConnect;
    }
    public bool Connect30003(string IPAddr)
    {
        bool isConnect = false;

        try
        { 
            if (_socket30003 == null)
            {
                _socket30003 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                _socket30003.Connect(IPAddr, 30003);
            }

            if (_socket30003.Connected)
            {
                Console.WriteLine("30003 Success");
                //_socket30003.Send(Encoding.Default.GetBytes("PolyscopeVersion".ToCharArray()));
                //_socket30003.Send(Encoding.Default.GetBytes("\n".ToCharArray()));
                //_socket30003.Receive(_DataByte30003);
                //Console.WriteLine(Analysis(_DataByte30003));
                //_socket30003.Receive(_DataByte30003);
                //Console.WriteLine(Analysis(_DataByte30003));
                isConnect = true;
                if (_getpos == null)
                {
                    _getActPos = true;
                    _getpos = new Task(GetPosition);
                    _getpos.Start();
                }
                else
                {
                    _getActPos = true;
                }
            }

        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.ToString());
            isConnect = false;
        }

        return isConnect;
    }



    public string PowerOn()
    {
        string Msg = "";
        try
        {
            if (_socket29999 != null)
            {
                if (_socket29999.Connected)
                {
                    _socket29999.Send(Encoding.Default.GetBytes("power on".ToCharArray()));
                    _socket29999.Send(Encoding.Default.GetBytes("\n".ToCharArray()));
                    _socket29999.Receive(_DataByte29999);
                    Msg = Analysis(_DataByte29999);
                }
            }
        }
        catch(Exception ex)
        {
            MessageBox.Show(ex.ToString());
            Msg = "Power On Fail";
        }
        return Msg;
    }
    public string PowerOff()
    {
        string Msg = "";
        try
        {
            if (_socket29999 != null)
            {
                if (_socket29999.Connected)
                {
                    _socket29999.Send(Encoding.Default.GetBytes("power off".ToCharArray()));
                    _socket29999.Send(Encoding.Default.GetBytes("\n".ToCharArray()));
                    _socket29999.Receive(_DataByte29999);
                    Msg = Analysis(_DataByte29999);
                }
            }
        }
        catch(Exception ex)
        {
            MessageBox.Show(ex.ToString());
            Msg = "Power Off Fail";
        }
        return Msg;
    }
    public string BrakeRelease()
    {
        string Msg = "";
        try
        {
            if (_socket29999 != null)
            {
                if (_socket29999.Connected)
                {
                    _socket29999.Send(Encoding.Default.GetBytes("brake release".ToCharArray()));
                    _socket29999.Send(Encoding.Default.GetBytes("\n".ToCharArray()));
                    _socket29999.Receive(_DataByte29999);
                    Msg = Analysis(_DataByte29999);
                }
            }
        }
        catch(Exception ex)
        {
            MessageBox.Show(ex.ToString());
            Msg = "Brake Release Fail";
        }
        return Msg;
    }
    public string Disconnect()
    {
        string Msg = "";
        try
        {
            if (_socket30003.Connected)
            {
                _getActPos = false;
                _socket30003.Dispose();
                //_socket30003.Disconnect(true);
                //_socket30003 = null;
            }

            if (_socket29999.Connected)
            {
                _socket29999.Send(Encoding.Default.GetBytes("quit".ToCharArray()));
                _socket29999.Send(Encoding.Default.GetBytes("\n".ToCharArray()));
                _socket29999.Send(Encoding.Default.GetBytes("quit".ToCharArray()));
                _socket29999.Send(Encoding.Default.GetBytes("\n".ToCharArray()));
                _socket29999.Receive(_DataByte29999);

                Msg = Analysis(_DataByte29999);

                _socket29999.Disconnect(true);
                _socket29999 = null;
            }



        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.ToString());
            Msg = "Disconnect Fail";
        }
        return Msg;
    }
    private string Analysis(byte[] DataByte)
    {
        string AnsString;
        int count = 0;
        foreach (var str in DataByte)
        {
            if (str != 10)
            {
                count++;
            }
            else
                break;
        }
        AnsString = _ascii.GetString(DataByte, 0, count);
        return AnsString;
    }
    public void Move(string Move)
    {
        string instruct;
        instruct = Move + "\r\n";
        if (_socket30003 != null)
        {
            if (_socket30003.Connected)
            {
                _socket30003.Send(Encoding.Default.GetBytes(instruct.ToArray()));
            }
        }
    }
    public void MoveL(double x, double y, double z, double rx, double ry, double rz, double acclerate = 0.3, double velocity = 0.1, double time = 0.0, double blendradius = 0.0)
    {
        string instruct;
        try
        {
            instruct = String.Format("movel(p[{0}, {1}, {2}, {3}, {4}, {5}], a = {6}, v = {7}, t = {8}, r = {9})\r\n",
                        x, y, z, rx, ry, rz, acclerate, velocity, time, blendradius);
            if (_socket30003 != null)
            {
                if (_socket30003.Connected)
                {
                    _socket30003.Send(Encoding.Default.GetBytes(instruct.ToArray()));
                }
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.ToString());
        }
    }
    public string Stop()
    {
        string Msg = "";
        try
        {
            _socket29999.Send(Encoding.Default.GetBytes("stop".ToCharArray()));
            _socket29999.Send(Encoding.Default.GetBytes("\n".ToCharArray()));
            _socket29999.Receive(_DataByte29999);
            Msg = Analysis(_DataByte29999);
        }
        catch(Exception ex)
        {
            MessageBox.Show(ex.ToString());
            Msg = "Robot Stop Fail";
        }
        return Msg;
    }

    public void ReadRoute()
    {
        try
        {
            _Route.Clear();
            OpenFileDialog opf = new OpenFileDialog();
            string line;

            opf.Filter = "txt file (*.txt)|*.txt;";
            opf.Multiselect = false;
            if (opf.ShowDialog() == DialogResult.OK)
            {
                using (StreamReader sr = new StreamReader(opf.FileName))
                {
                    while ((line = sr.ReadLine()) != null)
                    {
                        Console.WriteLine(line);
                        _Route.Add(line);
                    }
                }
            }
        }
        catch(Exception ex)
        {

        }

    }
    public void Run()
    {
        Thread threadRun = new Thread(RunRoute);
        threadRun.Start();
    }
    private void RunRoute()
    {
        string[] routeContext;
        string instruct = "";
        double x, y, z;

        if (_Route.Count != 0)
        {
            for (int i = 0; i < _Route.Count; i++)
            {
                routeContext = _Route[i].Split(',');

                x = Convert.ToDouble(routeContext[0]) / 1000;
                y = Convert.ToDouble(routeContext[1]) / 1000;
                z = Convert.ToDouble(routeContext[2]) / 1000;

                instruct = String.Format("movel(p[{0}, {1}, {2}, {3}, {4}, {5}], a = 0.3, v = 0.1, t = 0.0, r = 0.0)\r\n",
                x, y, z, routeContext[3], routeContext[4], routeContext[5]);

                _socket30003.Send(Encoding.Default.GetBytes(instruct.ToArray()));
                check(x, y, z);
                //Console.WriteLine(instruct);

            }
        }
    }
    private void check(double x, double y, double z)
    {
        while(true)
        {
            if(Math.Abs(_PosAngle[0] - x) * 1000 < 1 & Math.Abs(_PosAngle[1] - y) * 1000 < 1 & Math.Abs(_PosAngle[2] - z) * 1000 < 1)
            {
                break;
            }
            Thread.Sleep(1);
        }
    }
    private double BytesToDouble(byte[] Bytes, int StartIndex)
    {
        int ByteLength = 8;
        byte tVal;
        byte[] tmpByte = new byte[ByteLength];
        for (int i = 0; i < ByteLength - 1 ; i++)
        {
            tVal = Bytes[StartIndex + i];
            tmpByte[ByteLength-1-i] = tVal;
        }

        Double rtn = BitConverter.ToDouble(tmpByte, 0);
        return rtn;
    }
    private void GetPosition()
    {
        while (_getActPos)
        {
            if (_socket30003.Connected)
            {
                _socket30003.Receive(_DataByte30003);
                for (int i = 0; i < 5; i++)
                {
                    _PosAngle[i] = BytesToDouble(_DataByte30003, 444 + i * 8);
                }
            }
            else
            {
                break;
            }
        }
    }
}

